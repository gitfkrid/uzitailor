package views;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javaswingdev.Notification;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import koneksi.koneksi;

public class barang_edit extends javax.swing.JDialog {
    
    public Connection conn = new koneksi().connect();
    public views.barang barang = new views.barang();

    public barang_edit(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_exit = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lebar_dada = new javax.swing.JTextField();
        btn_batal = new javax.swing.JLabel();
        btn_tambah = new javax.swing.JButton();
        panjang_pakaian = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lebar_panggul = new javax.swing.JTextField();
        kode = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        lingkar_pinggang = new javax.swing.JTextField();
        lingkar_panggul = new javax.swing.JTextField();
        panjang_tangan = new javax.swing.JTextField();
        panjang_celana = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lingkar_dada = new javax.swing.JTextField();
        lingkar_perut = new javax.swing.JTextField();
        lebar_pinggul = new javax.swing.JTextField();
        lingkar_punggung = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        lingkar_lengan = new javax.swing.JTextField();
        set_lingkar_badan = new javax.swing.JTextField();
        lebar_pundak = new javax.swing.JTextField();
        lebar_badan = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        set_lingkar_lengan = new javax.swing.JTextField();
        panjang_lengan = new javax.swing.JTextField();
        tinggi_leher = new javax.swing.JTextField();
        lebar_bawah = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(javax.swing.UIManager.getDefaults().getColor("controlLtHighlight"));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel1.setPreferredSize(new java.awt.Dimension(450, 550));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        btn_exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_exitMouseClicked(evt);
            }
        });
        jPanel1.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, -1, -1));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 20)); // NOI18N
        jLabel1.setText("Tambah Data Barang");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 35, -1, -1));

        nama.setBackground(new java.awt.Color(237, 242, 244));
        nama.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        nama.setToolTipText("");
        nama.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        nama.setPreferredSize(new java.awt.Dimension(400, 30));
        jPanel1.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 102, -1, -1));

        jLabel2.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel2.setText("Nama Barang");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 85, -1, -1));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel3.setText("L Dada");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 152, -1, -1));

        lebar_dada.setBackground(new java.awt.Color(237, 242, 244));
        lebar_dada.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lebar_dada.setToolTipText("");
        lebar_dada.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lebar_dada.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lebar_dada, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 169, -1, -1));

        btn_batal.setFont(new java.awt.Font("Poppins", 0, 11)); // NOI18N
        btn_batal.setText("Batal");
        btn_batal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_batalMouseClicked(evt);
            }
        });
        jPanel1.add(btn_batal, new org.netbeans.lib.awtextra.AbsoluteConstraints(295, 498, -1, -1));

        btn_tambah.setBackground(new java.awt.Color(255, 255, 255));
        btn_tambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/edit.png"))); // NOI18N
        btn_tambah.setBorder(null);
        btn_tambah.setPreferredSize(new java.awt.Dimension(90, 30));
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });
        jPanel1.add(btn_tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 492, -1, -1));

        panjang_pakaian.setBackground(new java.awt.Color(237, 242, 244));
        panjang_pakaian.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        panjang_pakaian.setToolTipText("");
        panjang_pakaian.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        panjang_pakaian.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(panjang_pakaian, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 169, -1, -1));

        jLabel9.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel9.setText("P Pakaian");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 152, -1, -1));

        jLabel10.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel10.setText("L Panggul");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 152, -1, -1));

        lebar_panggul.setBackground(new java.awt.Color(237, 242, 244));
        lebar_panggul.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lebar_panggul.setToolTipText("");
        lebar_panggul.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lebar_panggul.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lebar_panggul, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 169, -1, -1));

        kode.setBackground(new java.awt.Color(237, 242, 244));
        kode.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode.setToolTipText("");
        kode.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(kode, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 169, -1, -1));

        jLabel4.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel4.setText("Kode Barang");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 152, -1, -1));

        lingkar_pinggang.setBackground(new java.awt.Color(237, 242, 244));
        lingkar_pinggang.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lingkar_pinggang.setToolTipText("");
        lingkar_pinggang.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lingkar_pinggang.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lingkar_pinggang, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 236, -1, -1));

        lingkar_panggul.setBackground(new java.awt.Color(237, 242, 244));
        lingkar_panggul.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lingkar_panggul.setToolTipText("");
        lingkar_panggul.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lingkar_panggul.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lingkar_panggul, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 236, -1, -1));

        panjang_tangan.setBackground(new java.awt.Color(237, 242, 244));
        panjang_tangan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        panjang_tangan.setToolTipText("");
        panjang_tangan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        panjang_tangan.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(panjang_tangan, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 236, -1, -1));

        panjang_celana.setBackground(new java.awt.Color(237, 242, 244));
        panjang_celana.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        panjang_celana.setToolTipText("");
        panjang_celana.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        panjang_celana.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(panjang_celana, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 236, -1, -1));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel5.setText("Lingkar Panggul");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 219, -1, -1));

        jLabel6.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel6.setText("Lingkar Pinggang");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 219, -1, -1));

        jLabel11.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel11.setText("P Tangan");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 219, -1, -1));

        jLabel12.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel12.setText("P Celana");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 219, -1, -1));

        lingkar_dada.setBackground(new java.awt.Color(237, 242, 244));
        lingkar_dada.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lingkar_dada.setToolTipText("");
        lingkar_dada.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lingkar_dada.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lingkar_dada, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 303, -1, -1));

        lingkar_perut.setBackground(new java.awt.Color(237, 242, 244));
        lingkar_perut.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lingkar_perut.setToolTipText("");
        lingkar_perut.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lingkar_perut.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lingkar_perut, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 303, -1, -1));

        lebar_pinggul.setBackground(new java.awt.Color(237, 242, 244));
        lebar_pinggul.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lebar_pinggul.setToolTipText("");
        lebar_pinggul.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lebar_pinggul.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lebar_pinggul, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 303, -1, -1));

        lingkar_punggung.setBackground(new java.awt.Color(237, 242, 244));
        lingkar_punggung.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lingkar_punggung.setToolTipText("");
        lingkar_punggung.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lingkar_punggung.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lingkar_punggung, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 303, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel7.setText("Lingkar Dada");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 286, -1, -1));

        jLabel8.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel8.setText("Lingkar Perut");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 286, -1, -1));

        jLabel13.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel13.setText("L Pinggul");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 286, -1, -1));

        jLabel14.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel14.setText("Lingkar Punggung");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 286, -1, -1));

        lingkar_lengan.setBackground(new java.awt.Color(237, 242, 244));
        lingkar_lengan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lingkar_lengan.setToolTipText("");
        lingkar_lengan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lingkar_lengan.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lingkar_lengan, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 370, -1, -1));

        set_lingkar_badan.setBackground(new java.awt.Color(237, 242, 244));
        set_lingkar_badan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        set_lingkar_badan.setToolTipText("");
        set_lingkar_badan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        set_lingkar_badan.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(set_lingkar_badan, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 370, -1, -1));

        lebar_pundak.setBackground(new java.awt.Color(237, 242, 244));
        lebar_pundak.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lebar_pundak.setToolTipText("");
        lebar_pundak.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lebar_pundak.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lebar_pundak, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 370, -1, -1));

        lebar_badan.setBackground(new java.awt.Color(237, 242, 244));
        lebar_badan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lebar_badan.setToolTipText("");
        lebar_badan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lebar_badan.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lebar_badan, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 370, -1, -1));

        jLabel15.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel15.setText("L Badan");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 353, -1, -1));

        jLabel16.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel16.setText("Lingkar Lengan");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 353, -1, -1));

        jLabel17.setFont(new java.awt.Font("Poppins", 0, 9)); // NOI18N
        jLabel17.setText("Set Lingkar Badan");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 353, -1, -1));

        jLabel18.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel18.setText("L Pundak");
        jLabel18.setToolTipText("");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 353, -1, -1));

        set_lingkar_lengan.setBackground(new java.awt.Color(237, 242, 244));
        set_lingkar_lengan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        set_lingkar_lengan.setToolTipText("");
        set_lingkar_lengan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        set_lingkar_lengan.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(set_lingkar_lengan, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 437, -1, -1));

        panjang_lengan.setBackground(new java.awt.Color(237, 242, 244));
        panjang_lengan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        panjang_lengan.setToolTipText("");
        panjang_lengan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        panjang_lengan.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(panjang_lengan, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 437, -1, -1));

        tinggi_leher.setBackground(new java.awt.Color(237, 242, 244));
        tinggi_leher.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        tinggi_leher.setToolTipText("");
        tinggi_leher.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        tinggi_leher.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(tinggi_leher, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 437, -1, -1));

        lebar_bawah.setBackground(new java.awt.Color(237, 242, 244));
        lebar_bawah.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        lebar_bawah.setToolTipText("");
        lebar_bawah.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        lebar_bawah.setPreferredSize(new java.awt.Dimension(90, 30));
        jPanel1.add(lebar_bawah, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 437, -1, -1));

        jLabel19.setFont(new java.awt.Font("Poppins", 0, 9)); // NOI18N
        jLabel19.setText("Set Lingkar Lengan");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 420, -1, -1));

        jLabel20.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel20.setText("Panjang Lengan");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(127, 420, -1, -1));

        jLabel21.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel21.setText("Tinggi Leher");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 420, -1, -1));

        jLabel22.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel22.setText("L Bawah");
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(335, 420, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_exitMouseClicked
        this.dispose();
    }//GEN-LAST:event_btn_exitMouseClicked

    private void btn_batalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_batalMouseClicked
        this.dispose();
    }//GEN-LAST:event_btn_batalMouseClicked

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        try {
            String sql= "UPDATE `master_barang` SET `nama_barang`='"+nama.getText()
            +"', `kode_barang`='"+kode.getText()
            +"',`lebar_dada`='"+lebar_dada.getText()
            +"',`panjang_pakaian`='"+panjang_pakaian.getText()
            +"',`lebar_panggul`='"+lebar_panggul.getText()
            +"',`lingkar_panggul`='"+lingkar_panggul.getText()
            +"',`lingkar_pinggang`='"+lingkar_pinggang.getText()
            +"',`panjang_tangan`='"+panjang_tangan.getText()
            +"',`panjang_celana`='"+panjang_celana.getText()
            +"',`lingkar_dada`='"+lingkar_dada.getText()
            +"',`lingkar_perut`='"+lingkar_perut.getText()
            +"',`lebar_pinggul`='"+lebar_pinggul.getText()
            +"',`lingkar_punggung`='"+lingkar_punggung.getText()
            +"',`lingkar_lengan`='"+lingkar_lengan.getText()
            +"',`set_lingkar_badan`='"+set_lingkar_badan.getText()
            +"',`lebar_pundak`='"+lebar_pundak.getText()
            +"',`lebar_badan`='"+lebar_badan.getText()
            +"',`set_lingkar_lengan`='"+set_lingkar_lengan.getText()
            +"',`panjang_lengan`='"+panjang_lengan.getText()
            +"',`tinggi_leher`='"+tinggi_leher.getText()
            +"',`lebar_bawah`='"+lebar_bawah.getText()
            + "' WHERE kode_barang='"+kode.getText()+"'";

            PreparedStatement state = conn.prepareStatement(sql);
            state.executeUpdate();
            Notification panel = new Notification(barang, Notification.Type.SUCCESS, Notification.Location.CENTER, "Data Berhasil Ditambahkan");
            panel.showNotification();
            this.dispose();

        } catch (SQLException ex) {
            Logger.getLogger(barang_edit.class.getName()).log(Level.SEVERE, null, ex);
            Notification panel = new Notification(barang, Notification.Type.WARNING, Notification.Location.CENTER, "Data Gagal Ditambahkan");
            panel.showNotification();
        }
    }//GEN-LAST:event_btn_tambahActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(barang_edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(barang_edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(barang_edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(barang_edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                barang_edit dialog = new barang_edit(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btn_batal;
    private javax.swing.JLabel btn_exit;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JTextField kode;
    public javax.swing.JTextField lebar_badan;
    public javax.swing.JTextField lebar_bawah;
    public javax.swing.JTextField lebar_dada;
    public javax.swing.JTextField lebar_panggul;
    public javax.swing.JTextField lebar_pinggul;
    public javax.swing.JTextField lebar_pundak;
    public javax.swing.JTextField lingkar_dada;
    public javax.swing.JTextField lingkar_lengan;
    public javax.swing.JTextField lingkar_panggul;
    public javax.swing.JTextField lingkar_perut;
    public javax.swing.JTextField lingkar_pinggang;
    public javax.swing.JTextField lingkar_punggung;
    public javax.swing.JTextField nama;
    public javax.swing.JTextField panjang_celana;
    public javax.swing.JTextField panjang_lengan;
    public javax.swing.JTextField panjang_pakaian;
    public javax.swing.JTextField panjang_tangan;
    public javax.swing.JTextField set_lingkar_badan;
    public javax.swing.JTextField set_lingkar_lengan;
    public javax.swing.JTextField tinggi_leher;
    // End of variables declaration//GEN-END:variables
}
