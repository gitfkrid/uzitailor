package views;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import koneksi.koneksi;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javaswingdev.Notification;

public class login extends javax.swing.JFrame {
    
    public Connection conn = new koneksi().connect();

    public login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        garis1 = new javax.swing.JLabel();
        field_password = new javax.swing.JPasswordField();
        garis = new javax.swing.JLabel();
        field_username = new javax.swing.JTextField();
        btn_login = new javax.swing.JButton();
        btn_exit = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Uzi Tailor - Login");
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(700, 500));
        jPanel1.setRequestFocusEnabled(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Poppins", 1, 31)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Uzi Tailor");
        jLabel2.setToolTipText("");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(103, 219, -1, -1));

        jLabel3.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Aplikasi Konveksi");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(128, 266, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/bg_login.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel4.setFont(new java.awt.Font("Staatliches", 0, 26)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(217, 4, 41));
        jLabel4.setText("UZI TAILOR");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 120, -1, -1));

        jLabel6.setFont(new java.awt.Font("Staatliches", 0, 26)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(43, 45, 66));
        jLabel6.setText("WELCOME TO");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 120, -1, -1));

        jLabel5.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(43, 45, 66));
        jLabel5.setText("Silakan masuk terlebih dahulu !");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 155, -1, -1));

        garis1.setForeground(new java.awt.Color(102, 102, 102));
        garis1.setText("___________________________________");
        jPanel1.add(garis1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 299, -1, -1));

        field_password.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        field_password.setBorder(null);
        field_password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                field_passwordKeyPressed(evt);
            }
        });
        jPanel1.add(field_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 281, 250, 30));

        garis.setForeground(new java.awt.Color(102, 102, 102));
        garis.setText("___________________________________");
        jPanel1.add(garis, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 224, -1, -1));

        field_username.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        field_username.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        field_username.setMinimumSize(new java.awt.Dimension(250, 20));
        field_username.setPreferredSize(new java.awt.Dimension(250, 20));
        field_username.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                field_usernameKeyPressed(evt);
            }
        });
        jPanel1.add(field_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 206, 250, 30));

        btn_login.setBackground(new java.awt.Color(255, 255, 255));
        btn_login.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        btn_login.setForeground(new java.awt.Color(255, 255, 255));
        btn_login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_grey.png"))); // NOI18N
        btn_login.setText("Login");
        btn_login.setBorder(null);
        btn_login.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_login.setMaximumSize(new java.awt.Dimension(100, 30));
        btn_login.setMinimumSize(new java.awt.Dimension(100, 30));
        btn_login.setPreferredSize(new java.awt.Dimension(100, 30));
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });
        jPanel1.add(btn_login, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 349, -1, -1));

        btn_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        btn_exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_exitMouseClicked(evt);
            }
        });
        jPanel1.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 10, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
        String level =""; 
        try {
            field_username.requestFocus();
            java.sql.Statement stat = conn.createStatement();
            ResultSet result=stat.executeQuery ("SELECT * FROM karyawan WHERE "
                + "id_karyawan='" +field_username.getText()+"'");
            if (result.next()) {
                if (field_password.getText().equals(result.getString("password"))){
                    if (result.getString("level").equals("A")) {
                        Notification panel = new Notification(this, Notification.Type.SUCCESS, Notification.Location.CENTER, "Selamat Datang");
                        panel.showNotification();
                        views.transaksi mn = new views.transaksi();
                        mn.setExtendedState(JFrame.NORMAL);
                        mn.setVisible(true);
                        this.dispose();
                    }
                    else if (result.getString("level").equals("K")) {
                        //new menuUtama().show();
                        JOptionPane.showMessageDialog(rootPane, "Selamat Datang  "+field_username.getText());
                        views.transaksi mn = new views.transaksi();
                        mn.setExtendedState(JFrame.NORMAL);
                        mn.setVisible(true);
                        this.dispose();
                    }
                } else {
                    Notification panel = new Notification(this, Notification.Type.INFO, Notification.Location.CENTER, "Password Salah");
                    panel.showNotification();
                    field_password.setText("");
                    field_username.requestFocus();
                }
            } else {
                Notification panel = new Notification(this, Notification.Type.WARNING, Notification.Location.CENTER, "User Tidak Ditemukan");
                panel.showNotification();
                field_username.setText("");
                field_password.setText("");
                field_username.requestFocus();
            }
        } catch (Exception e){
            JOptionPane.showMessageDialog(rootPane, "Gagal");
        }
    }//GEN-LAST:event_btn_loginActionPerformed

    private void btn_exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_exitMouseClicked
        System.exit(0);
    }//GEN-LAST:event_btn_exitMouseClicked

    private void field_usernameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_field_usernameKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            field_password.requestFocus();
        }
    }//GEN-LAST:event_field_usernameKeyPressed

    private void field_passwordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_field_passwordKeyPressed
        if (evt.getKeyCode()== KeyEvent.VK_ENTER) {
            btn_loginActionPerformed(new ActionEvent(evt.getSource(), evt.getID(), "Key Press Login"));
        }
    }//GEN-LAST:event_field_passwordKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btn_exit;
    private javax.swing.JButton btn_login;
    private javax.swing.JPasswordField field_password;
    private javax.swing.JTextField field_username;
    private javax.swing.JLabel garis;
    private javax.swing.JLabel garis1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
