package views;

public class transaksi extends javax.swing.JFrame {

    public transaksi() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        frame = new javax.swing.JPanel();
        btn_exit = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        title = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        transaksi = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        order = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        barang = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        riwayat = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        laporan = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        akun = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        Konfigurasi = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        about = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Uzi Tailor - Transaksi");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        frame.setBackground(new java.awt.Color(255, 255, 255));
        frame.setPreferredSize(new java.awt.Dimension(1024, 576));
        frame.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        btn_exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_exitMouseClicked(evt);
            }
        });
        frame.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(994, 10, -1, -1));

        menu.setBackground(new java.awt.Color(43, 45, 66));
        menu.setPreferredSize(new java.awt.Dimension(150, 576));
        menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        title.setBackground(new java.awt.Color(217, 4, 41));
        title.setPreferredSize(new java.awt.Dimension(125, 50));
        title.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Staatliches", 0, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("uzi tailor");
        title.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 15, -1, -1));

        menu.add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 150, -1));

        transaksi.setBackground(new java.awt.Color(65, 68, 96));
        transaksi.setPreferredSize(new java.awt.Dimension(150, 30));
        transaksi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/transaksi.png"))); // NOI18N
        transaksi.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Transaksi");
        transaksi.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(transaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));

        order.setBackground(new java.awt.Color(43, 45, 66));
        order.setPreferredSize(new java.awt.Dimension(150, 30));
        order.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                orderMouseClicked(evt);
            }
        });
        order.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/proses.png"))); // NOI18N
        order.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Order on Progress");
        order.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(order, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, -1, -1));

        barang.setBackground(new java.awt.Color(43, 45, 66));
        barang.setPreferredSize(new java.awt.Dimension(150, 30));
        barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                barangMouseClicked(evt);
            }
        });
        barang.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/barang.png"))); // NOI18N
        barang.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Master Barang");
        barang.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(barang, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, -1, -1));

        riwayat.setBackground(new java.awt.Color(43, 45, 66));
        riwayat.setPreferredSize(new java.awt.Dimension(150, 30));
        riwayat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                riwayatMouseClicked(evt);
            }
        });
        riwayat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/riwayat.png"))); // NOI18N
        riwayat.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel9.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Riwayat Transaksi");
        riwayat.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(riwayat, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, -1, -1));

        laporan.setBackground(new java.awt.Color(43, 45, 66));
        laporan.setPreferredSize(new java.awt.Dimension(150, 30));
        laporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                laporanMouseClicked(evt);
            }
        });
        laporan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/laporan.png"))); // NOI18N
        laporan.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel11.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Laporan Penjualan");
        laporan.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(laporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, -1, -1));

        akun.setBackground(new java.awt.Color(43, 45, 66));
        akun.setPreferredSize(new java.awt.Dimension(150, 30));
        akun.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                akunMouseClicked(evt);
            }
        });
        akun.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/akun.png"))); // NOI18N
        akun.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel13.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Master Akun");
        akun.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(akun, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, -1, -1));

        Konfigurasi.setBackground(new java.awt.Color(43, 45, 66));
        Konfigurasi.setPreferredSize(new java.awt.Dimension(150, 30));
        Konfigurasi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KonfigurasiMouseClicked(evt);
            }
        });
        Konfigurasi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/konfigurasi.png"))); // NOI18N
        Konfigurasi.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel15.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Konfigurasi");
        Konfigurasi.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(Konfigurasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, -1, -1));

        about.setBackground(new java.awt.Color(43, 45, 66));
        about.setPreferredSize(new java.awt.Dimension(150, 30));
        about.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/about.png"))); // NOI18N
        about.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel17.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("About Us");
        about.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(about, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, -1, -1));

        frame.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(frame, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_exitMouseClicked
        views.login logout = new views.login();
        logout.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_exitMouseClicked

    private void orderMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orderMouseClicked
        views.order order = new views.order();
        order.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_orderMouseClicked

    private void barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barangMouseClicked
        views.barang barang = new views.barang();
        barang.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_barangMouseClicked

    private void riwayatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_riwayatMouseClicked
        views.riwayat riwayat = new views.riwayat();
        riwayat.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_riwayatMouseClicked

    private void laporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_laporanMouseClicked
        views.laporan laporan = new views.laporan();
        laporan.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_laporanMouseClicked

    private void akunMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_akunMouseClicked
        views.akun akun = new views.akun();
        akun.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_akunMouseClicked

    private void KonfigurasiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KonfigurasiMouseClicked
        views.konfigurasi konfigurasi = new views.konfigurasi();
        konfigurasi.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_KonfigurasiMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Konfigurasi;
    private javax.swing.JPanel about;
    private javax.swing.JPanel akun;
    private javax.swing.JPanel barang;
    private javax.swing.JLabel btn_exit;
    private javax.swing.JPanel frame;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel laporan;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel order;
    private javax.swing.JPanel riwayat;
    private javax.swing.JPanel title;
    private javax.swing.JPanel transaksi;
    // End of variables declaration//GEN-END:variables
}
