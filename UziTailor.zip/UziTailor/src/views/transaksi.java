package views;

public class transaksi extends javax.swing.JFrame {

    public transaksi() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        frame = new javax.swing.JPanel();
        btn_exit = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        title = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        transaksi = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        order = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        barang = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        riwayat = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        laporan = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        akun = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        Konfigurasi = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        about = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        nama1 = new javax.swing.JTextField();
        nama2 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        nama3 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        kode = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        kode1 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        kode2 = new javax.swing.JTextField();
        kode3 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        kode4 = new javax.swing.JTextField();
        kode5 = new javax.swing.JTextField();
        kode6 = new javax.swing.JTextField();
        kode7 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        kode8 = new javax.swing.JTextField();
        kode9 = new javax.swing.JTextField();
        kode10 = new javax.swing.JTextField();
        kode11 = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        kode12 = new javax.swing.JTextField();
        kode13 = new javax.swing.JTextField();
        kode14 = new javax.swing.JTextField();
        kode15 = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        kode16 = new javax.swing.JTextField();
        kode17 = new javax.swing.JTextField();
        kode18 = new javax.swing.JTextField();
        kode19 = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        kode20 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        kode21 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tb_barang = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Uzi Tailor - Transaksi");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        frame.setBackground(new java.awt.Color(255, 255, 255));
        frame.setPreferredSize(new java.awt.Dimension(1024, 576));
        frame.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        btn_exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_exitMouseClicked(evt);
            }
        });
        frame.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(994, 10, -1, -1));

        menu.setBackground(new java.awt.Color(43, 45, 66));
        menu.setPreferredSize(new java.awt.Dimension(150, 576));
        menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        title.setBackground(new java.awt.Color(217, 4, 41));
        title.setPreferredSize(new java.awt.Dimension(125, 50));
        title.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Staatliches", 0, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("uzi tailor");
        title.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 15, -1, -1));

        menu.add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 150, -1));

        transaksi.setBackground(new java.awt.Color(65, 68, 96));
        transaksi.setPreferredSize(new java.awt.Dimension(150, 30));
        transaksi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/transaksi.png"))); // NOI18N
        transaksi.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Transaksi");
        transaksi.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(transaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));

        order.setBackground(new java.awt.Color(43, 45, 66));
        order.setPreferredSize(new java.awt.Dimension(150, 30));
        order.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                orderMouseClicked(evt);
            }
        });
        order.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/proses.png"))); // NOI18N
        order.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Order on Progress");
        order.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(order, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, -1, -1));

        barang.setBackground(new java.awt.Color(43, 45, 66));
        barang.setPreferredSize(new java.awt.Dimension(150, 30));
        barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                barangMouseClicked(evt);
            }
        });
        barang.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/barang.png"))); // NOI18N
        barang.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Master Barang");
        barang.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(barang, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, -1, -1));

        riwayat.setBackground(new java.awt.Color(43, 45, 66));
        riwayat.setPreferredSize(new java.awt.Dimension(150, 30));
        riwayat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                riwayatMouseClicked(evt);
            }
        });
        riwayat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/riwayat.png"))); // NOI18N
        riwayat.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel9.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Riwayat Transaksi");
        riwayat.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(riwayat, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, -1, -1));

        laporan.setBackground(new java.awt.Color(43, 45, 66));
        laporan.setPreferredSize(new java.awt.Dimension(150, 30));
        laporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                laporanMouseClicked(evt);
            }
        });
        laporan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/laporan.png"))); // NOI18N
        laporan.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel11.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Laporan Penjualan");
        laporan.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(laporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, -1, -1));

        akun.setBackground(new java.awt.Color(43, 45, 66));
        akun.setPreferredSize(new java.awt.Dimension(150, 30));
        akun.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                akunMouseClicked(evt);
            }
        });
        akun.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/akun.png"))); // NOI18N
        akun.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel13.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Master Akun");
        akun.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(akun, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, -1, -1));

        Konfigurasi.setBackground(new java.awt.Color(43, 45, 66));
        Konfigurasi.setPreferredSize(new java.awt.Dimension(150, 30));
        Konfigurasi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KonfigurasiMouseClicked(evt);
            }
        });
        Konfigurasi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/konfigurasi.png"))); // NOI18N
        Konfigurasi.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel15.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Konfigurasi");
        Konfigurasi.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(Konfigurasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, -1, -1));

        about.setBackground(new java.awt.Color(43, 45, 66));
        about.setPreferredSize(new java.awt.Dimension(150, 30));
        about.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/about.png"))); // NOI18N
        about.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel17.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("About Us");
        about.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu.add(about, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, -1, -1));

        frame.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        nama.setBackground(new java.awt.Color(237, 242, 244));
        nama.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        nama.setToolTipText("");
        nama.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        nama.setPreferredSize(new java.awt.Dimension(198, 21));
        frame.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 64, -1, -1));

        jLabel18.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel18.setText("Id Pembeli");
        frame.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 47, -1, -1));

        jLabel19.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel19.setText("Id Pembeli");
        frame.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 47, -1, -1));

        nama1.setBackground(new java.awt.Color(237, 242, 244));
        nama1.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        nama1.setToolTipText("");
        nama1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        nama1.setPreferredSize(new java.awt.Dimension(198, 21));
        frame.add(nama1, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 64, -1, -1));

        nama2.setBackground(new java.awt.Color(237, 242, 244));
        nama2.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        nama2.setToolTipText("");
        nama2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        nama2.setPreferredSize(new java.awt.Dimension(198, 21));
        frame.add(nama2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 112, -1, -1));

        jLabel20.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel20.setText("Id Pembeli");
        frame.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 95, -1, -1));

        nama3.setBackground(new java.awt.Color(237, 242, 244));
        nama3.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        nama3.setToolTipText("");
        nama3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        nama3.setPreferredSize(new java.awt.Dimension(198, 21));
        frame.add(nama3, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 112, -1, -1));

        jLabel21.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel21.setText("Id Pembeli");
        frame.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 95, -1, -1));

        jLabel22.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel22.setText("Kode Barang");
        frame.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 153, -1, -1));

        kode.setBackground(new java.awt.Color(237, 242, 244));
        kode.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode.setToolTipText("");
        kode.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, -1, -1));

        jLabel23.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel23.setText("Kode Barang");
        frame.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 153, -1, -1));

        kode1.setBackground(new java.awt.Color(237, 242, 244));
        kode1.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode1.setToolTipText("");
        kode1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode1.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode1, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 170, -1, -1));

        jLabel24.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel24.setText("Kode Barang");
        frame.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 153, -1, -1));

        kode2.setBackground(new java.awt.Color(237, 242, 244));
        kode2.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode2.setToolTipText("");
        kode2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode2.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode2, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 170, -1, -1));

        kode3.setBackground(new java.awt.Color(237, 242, 244));
        kode3.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode3.setToolTipText("");
        kode3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode3.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode3, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 170, -1, -1));

        jLabel25.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel25.setText("Kode Barang");
        frame.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 153, -1, -1));

        jLabel26.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel26.setText("Kode Barang");
        frame.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 201, -1, -1));

        jLabel27.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel27.setText("Kode Barang");
        frame.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 201, -1, -1));

        jLabel28.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel28.setText("Kode Barang");
        frame.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 201, -1, -1));

        jLabel29.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel29.setText("Kode Barang");
        frame.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 201, -1, -1));

        kode4.setBackground(new java.awt.Color(237, 242, 244));
        kode4.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode4.setToolTipText("");
        kode4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode4.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 218, -1, -1));

        kode5.setBackground(new java.awt.Color(237, 242, 244));
        kode5.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode5.setToolTipText("");
        kode5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode5.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode5, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 218, -1, -1));

        kode6.setBackground(new java.awt.Color(237, 242, 244));
        kode6.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode6.setToolTipText("");
        kode6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode6.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode6, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 218, -1, -1));

        kode7.setBackground(new java.awt.Color(237, 242, 244));
        kode7.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode7.setToolTipText("");
        kode7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode7.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode7, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 218, -1, -1));

        jLabel30.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel30.setText("Kode Barang");
        frame.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 249, -1, -1));

        jLabel31.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel31.setText("Kode Barang");
        frame.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 249, -1, -1));

        jLabel32.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel32.setText("Kode Barang");
        frame.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 249, -1, -1));

        jLabel33.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel33.setText("Kode Barang");
        frame.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 249, -1, -1));

        kode8.setBackground(new java.awt.Color(237, 242, 244));
        kode8.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode8.setToolTipText("");
        kode8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode8.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode8, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 266, -1, -1));

        kode9.setBackground(new java.awt.Color(237, 242, 244));
        kode9.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode9.setToolTipText("");
        kode9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode9.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode9, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 266, -1, -1));

        kode10.setBackground(new java.awt.Color(237, 242, 244));
        kode10.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode10.setToolTipText("");
        kode10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode10.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode10, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 266, -1, -1));

        kode11.setBackground(new java.awt.Color(237, 242, 244));
        kode11.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode11.setToolTipText("");
        kode11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode11.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode11, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 266, -1, -1));

        jLabel34.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel34.setText("Kode Barang");
        frame.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 297, -1, -1));

        jLabel35.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel35.setText("Kode Barang");
        frame.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 297, -1, -1));

        jLabel36.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel36.setText("Kode Barang");
        frame.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 297, -1, -1));

        jLabel37.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel37.setText("Kode Barang");
        frame.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 297, -1, -1));

        kode12.setBackground(new java.awt.Color(237, 242, 244));
        kode12.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode12.setToolTipText("");
        kode12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode12.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode12, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 314, -1, -1));

        kode13.setBackground(new java.awt.Color(237, 242, 244));
        kode13.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode13.setToolTipText("");
        kode13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode13.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode13, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 314, -1, -1));

        kode14.setBackground(new java.awt.Color(237, 242, 244));
        kode14.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode14.setToolTipText("");
        kode14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode14.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode14, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 314, -1, -1));

        kode15.setBackground(new java.awt.Color(237, 242, 244));
        kode15.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode15.setToolTipText("");
        kode15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode15.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode15, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 314, -1, -1));

        jLabel38.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel38.setText("Kode Barang");
        frame.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 345, -1, -1));

        jLabel39.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel39.setText("Kode Barang");
        frame.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 345, -1, -1));

        jLabel40.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel40.setText("Kode Barang");
        frame.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 345, -1, -1));

        jLabel41.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel41.setText("Kode Barang");
        frame.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 345, -1, -1));

        kode16.setBackground(new java.awt.Color(237, 242, 244));
        kode16.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode16.setToolTipText("");
        kode16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode16.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode16, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 362, -1, -1));

        kode17.setBackground(new java.awt.Color(237, 242, 244));
        kode17.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode17.setToolTipText("");
        kode17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode17.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode17, new org.netbeans.lib.awtextra.AbsoluteConstraints(278, 362, -1, -1));

        kode18.setBackground(new java.awt.Color(237, 242, 244));
        kode18.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode18.setToolTipText("");
        kode18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode18.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode18, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 362, -1, -1));

        kode19.setBackground(new java.awt.Color(237, 242, 244));
        kode19.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode19.setToolTipText("");
        kode19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode19.setPreferredSize(new java.awt.Dimension(90, 21));
        frame.add(kode19, new org.netbeans.lib.awtextra.AbsoluteConstraints(496, 362, -1, -1));

        jLabel42.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel42.setText("Qty");
        frame.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 393, -1, -1));

        kode20.setBackground(new java.awt.Color(237, 242, 244));
        kode20.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode20.setToolTipText("");
        kode20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode20.setPreferredSize(new java.awt.Dimension(50, 21));
        frame.add(kode20, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 410, -1, -1));

        jLabel43.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel43.setText("Kode Barang");
        frame.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 393, -1, -1));

        kode21.setBackground(new java.awt.Color(237, 242, 244));
        kode21.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode21.setToolTipText("");
        kode21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode21.setPreferredSize(new java.awt.Dimension(360, 53));
        frame.add(kode21, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 410, -1, -1));

        jPanel1.setPreferredSize(new java.awt.Dimension(403, 83));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField1.setBackground(new java.awt.Color(43, 45, 66));
        jTextField1.setFont(new java.awt.Font("Poppins SemiBold", 1, 36)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(255, 255, 255));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField1.setText("jTextField1");
        jTextField1.setBorder(null);
        jTextField1.setPreferredSize(new java.awt.Dimension(390, 68));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 15, -1, -1));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/total.png"))); // NOI18N
        jPanel1.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        frame.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(602, 50, -1, -1));

        jScrollPane2.setAutoscrolls(true);
        jScrollPane2.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jScrollPane2.setPreferredSize(new java.awt.Dimension(402, 230));

        tb_barang.setFont(new java.awt.Font("Poppins", 0, 11)); // NOI18N
        tb_barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode Barang", "Nama Barang", "Harga", "Qty", "Total Harga"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tb_barang.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tb_barang.setGridColor(new java.awt.Color(43, 45, 66));
        tb_barang.setPreferredSize(new java.awt.Dimension(402, 230));
        tb_barang.setRowHeight(20);
        tb_barang.setSelectionBackground(new java.awt.Color(239, 35, 60));
        tb_barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_barangMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tb_barang);

        frame.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(602, 153, -1, 310));

        getContentPane().add(frame, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_exitMouseClicked
        views.login logout = new views.login();
        logout.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_exitMouseClicked

    private void orderMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orderMouseClicked
        views.order order = new views.order();
        order.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_orderMouseClicked

    private void barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barangMouseClicked
        views.barang barang = new views.barang();
        barang.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_barangMouseClicked

    private void riwayatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_riwayatMouseClicked
        views.riwayat riwayat = new views.riwayat();
        riwayat.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_riwayatMouseClicked

    private void laporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_laporanMouseClicked
        views.laporan laporan = new views.laporan();
        laporan.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_laporanMouseClicked

    private void akunMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_akunMouseClicked
        views.akun akun = new views.akun();
        akun.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_akunMouseClicked

    private void KonfigurasiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KonfigurasiMouseClicked
        views.konfigurasi konfigurasi = new views.konfigurasi();
        konfigurasi.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_KonfigurasiMouseClicked

    private void tb_barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_barangMouseClicked
        int row;
        row=tb_barang.getSelectedRow();
        /*txt_search.setText(model.getValueAt(row, 2).toString());
        removeRow();
        cari();*/
    }//GEN-LAST:event_tb_barangMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(transaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Konfigurasi;
    private javax.swing.JPanel about;
    private javax.swing.JPanel akun;
    private javax.swing.JPanel barang;
    private javax.swing.JLabel btn_exit;
    private javax.swing.JPanel frame;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    public static javax.swing.JTextField kode;
    public static javax.swing.JTextField kode1;
    public static javax.swing.JTextField kode10;
    public static javax.swing.JTextField kode11;
    public static javax.swing.JTextField kode12;
    public static javax.swing.JTextField kode13;
    public static javax.swing.JTextField kode14;
    public static javax.swing.JTextField kode15;
    public static javax.swing.JTextField kode16;
    public static javax.swing.JTextField kode17;
    public static javax.swing.JTextField kode18;
    public static javax.swing.JTextField kode19;
    public static javax.swing.JTextField kode2;
    public static javax.swing.JTextField kode20;
    public static javax.swing.JTextField kode21;
    public static javax.swing.JTextField kode3;
    public static javax.swing.JTextField kode4;
    public static javax.swing.JTextField kode5;
    public static javax.swing.JTextField kode6;
    public static javax.swing.JTextField kode7;
    public static javax.swing.JTextField kode8;
    public static javax.swing.JTextField kode9;
    private javax.swing.JPanel laporan;
    private javax.swing.JPanel menu;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField nama1;
    private javax.swing.JTextField nama2;
    private javax.swing.JTextField nama3;
    private javax.swing.JPanel order;
    private javax.swing.JPanel riwayat;
    public static javax.swing.JTable tb_barang;
    private javax.swing.JPanel title;
    private javax.swing.JPanel transaksi;
    // End of variables declaration//GEN-END:variables
}
