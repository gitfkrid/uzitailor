package views;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import koneksi.koneksi;

public class konfigurasi extends javax.swing.JFrame {
    public Connection conn = new koneksi().connect();
  public void isitxt(){
    String sql = "SELECT * FROM toko;";
        try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while (hasil.next()) {
                nama_toko.setText(hasil.getString("nama_toko")); 
                alamat_toko.setText(hasil.getString("alamat_toko")); 
                kota_toko.setText(hasil.getString("kota")); 
            }
        } catch (SQLException e) {
        }
  }
        
    public konfigurasi() {
        initComponents();
        isitxt();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        frame1 = new javax.swing.JPanel();
        btn_exit1 = new javax.swing.JLabel();
        menu1 = new javax.swing.JPanel();
        title1 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        transaksi1 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        order1 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        barang1 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        riwayat1 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        laporan1 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        akun1 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        Konfigurasi1 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        about1 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        nama_toko = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        alamat_toko = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        kota_toko = new javax.swing.JTextField();
        btn_editStruk = new javax.swing.JButton();
        btn_edit_akun = new javax.swing.JButton();
        nama_karyawan = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        password = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        nohp = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        alamat_karyawan = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        btn_print = new javax.swing.JButton();
        btn_upload = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Uzi Tailor - Konfigurasi");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        frame1.setBackground(new java.awt.Color(255, 255, 255));
        frame1.setPreferredSize(new java.awt.Dimension(1024, 576));
        frame1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_exit1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        btn_exit1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_exit1MouseClicked(evt);
            }
        });
        frame1.add(btn_exit1, new org.netbeans.lib.awtextra.AbsoluteConstraints(994, 10, -1, -1));

        menu1.setBackground(new java.awt.Color(43, 45, 66));
        menu1.setPreferredSize(new java.awt.Dimension(150, 576));
        menu1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        title1.setBackground(new java.awt.Color(217, 4, 41));
        title1.setPreferredSize(new java.awt.Dimension(125, 50));
        title1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setFont(new java.awt.Font("Staatliches", 0, 16)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("uzi tailor");
        title1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 15, -1, -1));

        menu1.add(title1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 150, -1));

        transaksi1.setBackground(new java.awt.Color(43, 45, 66));
        transaksi1.setPreferredSize(new java.awt.Dimension(150, 30));
        transaksi1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                transaksi1MouseClicked(evt);
            }
        });
        transaksi1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/transaksi.png"))); // NOI18N
        transaksi1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel20.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Transaksi");
        transaksi1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(transaksi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));

        order1.setBackground(new java.awt.Color(43, 45, 66));
        order1.setPreferredSize(new java.awt.Dimension(150, 30));
        order1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                order1MouseClicked(evt);
            }
        });
        order1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/proses.png"))); // NOI18N
        order1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel22.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Order on Progress");
        order1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(order1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, -1, -1));

        barang1.setBackground(new java.awt.Color(43, 45, 66));
        barang1.setPreferredSize(new java.awt.Dimension(150, 30));
        barang1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                barang1MouseClicked(evt);
            }
        });
        barang1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/barang.png"))); // NOI18N
        barang1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel24.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Master Barang");
        barang1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(barang1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, -1, -1));

        riwayat1.setBackground(new java.awt.Color(43, 45, 66));
        riwayat1.setPreferredSize(new java.awt.Dimension(150, 30));
        riwayat1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                riwayat1MouseClicked(evt);
            }
        });
        riwayat1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/riwayat.png"))); // NOI18N
        riwayat1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel26.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Riwayat Transaksi");
        riwayat1.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(riwayat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, -1, -1));

        laporan1.setBackground(new java.awt.Color(43, 45, 66));
        laporan1.setPreferredSize(new java.awt.Dimension(150, 30));
        laporan1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                laporan1MouseClicked(evt);
            }
        });
        laporan1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/laporan.png"))); // NOI18N
        laporan1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel28.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Laporan Penjualan");
        laporan1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(laporan1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, -1, -1));

        akun1.setBackground(new java.awt.Color(43, 45, 66));
        akun1.setPreferredSize(new java.awt.Dimension(150, 30));
        akun1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                akun1MouseClicked(evt);
            }
        });
        akun1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/akun.png"))); // NOI18N
        akun1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel30.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Master Akun");
        akun1.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(akun1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, -1, -1));

        Konfigurasi1.setBackground(new java.awt.Color(65, 68, 96));
        Konfigurasi1.setPreferredSize(new java.awt.Dimension(150, 30));
        Konfigurasi1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/konfigurasi.png"))); // NOI18N
        Konfigurasi1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel32.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Konfigurasi");
        Konfigurasi1.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(Konfigurasi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, -1, -1));

        about1.setBackground(new java.awt.Color(43, 45, 66));
        about1.setPreferredSize(new java.awt.Dimension(150, 30));
        about1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/about.png"))); // NOI18N
        about1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 7, -1, -1));

        jLabel34.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("About Us");
        about1.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 7, -1, -1));

        menu1.add(about1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, -1, -1));

        frame1.add(menu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel35.setFont(new java.awt.Font("Poppins", 1, 16)); // NOI18N
        jLabel35.setText("KONFIGURASI STRUK");
        jLabel35.setPreferredSize(new java.awt.Dimension(166, 24));
        frame1.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 50, -1, -1));

        nama_toko.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(nama_toko, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 111, 300, 27));

        jLabel36.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel36.setText("Nama Toko");
        frame1.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 97, 60, 12));

        alamat_toko.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(alamat_toko, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 171, 300, 176));

        jLabel37.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel37.setText("Kota");
        frame1.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 358, 30, 12));

        jLabel38.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel38.setText("Alamat Toko");
        frame1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 154, 70, 12));

        kota_toko.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(kota_toko, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 372, 300, 27));

        btn_editStruk.setBackground(new java.awt.Color(255, 255, 255));
        btn_editStruk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_editStruk.png"))); // NOI18N
        btn_editStruk.setBorder(null);
        btn_editStruk.setPreferredSize(new java.awt.Dimension(90, 30));
        btn_editStruk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editStrukActionPerformed(evt);
            }
        });
        frame1.add(btn_editStruk, new org.netbeans.lib.awtextra.AbsoluteConstraints(353, 430, -1, -1));

        btn_edit_akun.setBackground(new java.awt.Color(255, 255, 255));
        btn_edit_akun.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_editAkun.png"))); // NOI18N
        btn_edit_akun.setBorder(null);
        btn_edit_akun.setPreferredSize(new java.awt.Dimension(90, 30));
        btn_edit_akun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_edit_akunActionPerformed(evt);
            }
        });
        frame1.add(btn_edit_akun, new org.netbeans.lib.awtextra.AbsoluteConstraints(695, 429, 80, 30));

        nama_karyawan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(nama_karyawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 197, 198, 21));

        jLabel39.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel39.setText("Nama Lengkap");
        frame1.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 180, 80, 12));

        username.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 245, 198, 21));

        jLabel40.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel40.setText("Username");
        frame1.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 228, 60, 12));

        password.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 293, 198, 21));

        jLabel41.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel41.setText("Password");
        frame1.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 276, 60, 12));

        nohp.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(nohp, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 341, 198, 21));

        jLabel42.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel42.setText("No HP");
        frame1.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 324, 30, 12));

        alamat_karyawan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        frame1.add(alamat_karyawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 389, 198, 21));

        jLabel43.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel43.setText("Alamat");
        frame1.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(675, 372, 40, 12));

        btn_print.setBackground(new java.awt.Color(255, 255, 255));
        btn_print.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_print.png"))); // NOI18N
        btn_print.setBorder(null);
        btn_print.setPreferredSize(new java.awt.Dimension(90, 30));
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });
        frame1.add(btn_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(463, 429, -1, -1));

        btn_upload.setBackground(new java.awt.Color(255, 255, 255));
        btn_upload.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_upload_foto.png"))); // NOI18N
        btn_upload.setBorder(null);
        btn_upload.setPreferredSize(new java.awt.Dimension(90, 30));
        btn_upload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_uploadActionPerformed(evt);
            }
        });
        frame1.add(btn_upload, new org.netbeans.lib.awtextra.AbsoluteConstraints(793, 429, 80, 30));

        getContentPane().add(frame1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_exit1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_exit1MouseClicked
        views.login logout = new views.login();
        logout.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_exit1MouseClicked

    private void transaksi1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_transaksi1MouseClicked
        views.transaksi transaksi = new views.transaksi();
        transaksi.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_transaksi1MouseClicked

    private void order1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_order1MouseClicked
        views.order order = new views.order();
        order.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_order1MouseClicked

    private void barang1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barang1MouseClicked
        views.barang barang = new views.barang();
        barang.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_barang1MouseClicked

    private void riwayat1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_riwayat1MouseClicked
        views.riwayat riwayat = new views.riwayat();
        riwayat.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_riwayat1MouseClicked

    private void laporan1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_laporan1MouseClicked
        views.laporan laporan = new views.laporan();
        laporan.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_laporan1MouseClicked

    private void akun1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_akun1MouseClicked
        views.akun akun = new views.akun();
        akun.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_akun1MouseClicked

    private void btn_editStrukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editStrukActionPerformed

    }//GEN-LAST:event_btn_editStrukActionPerformed

    private void btn_edit_akunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_edit_akunActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_edit_akunActionPerformed

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_printActionPerformed

    private void btn_uploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_uploadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_uploadActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new konfigurasi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Konfigurasi1;
    private javax.swing.JPanel about1;
    private javax.swing.JPanel akun1;
    private javax.swing.JTextField alamat_karyawan;
    private javax.swing.JTextField alamat_toko;
    private javax.swing.JPanel barang1;
    private javax.swing.JButton btn_editStruk;
    private javax.swing.JButton btn_edit_akun;
    private javax.swing.JLabel btn_exit1;
    private javax.swing.JButton btn_print;
    private javax.swing.JButton btn_upload;
    private javax.swing.JPanel frame1;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JTextField kota_toko;
    private javax.swing.JPanel laporan1;
    private javax.swing.JPanel menu1;
    private javax.swing.JTextField nama_karyawan;
    private javax.swing.JTextField nama_toko;
    private javax.swing.JTextField nohp;
    private javax.swing.JPanel order1;
    private javax.swing.JTextField password;
    private javax.swing.JPanel riwayat1;
    private javax.swing.JPanel title1;
    private javax.swing.JPanel transaksi1;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
