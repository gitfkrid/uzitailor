package frame;

import java.awt.Color;
import javafr.PanelSwaper;
import javax.swing.JOptionPane;
import model.Login;
import panel.akun;
import panel.barang;
import panel.laporan;
import panel.order;
import panel.pembeli;
import panel.riwayat;
import panel.transaksi;

public class main extends javax.swing.JFrame {
    Login Login;
    
    public main() {
        initComponents();
        body.removeAll();
        body.add(new PanelSwaper(new transaksi(this)));
        body.updateUI();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Header = new javax.swing.JPanel();
        iconminmaxclose = new javax.swing.JPanel();
        Buttonclose = new javax.swing.JPanel();
        close = new javax.swing.JLabel();
        Buttonmax = new javax.swing.JPanel();
        fullmax = new javax.swing.JLabel();
        ButtonMin = new javax.swing.JPanel();
        minimize = new javax.swing.JLabel();
        title = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        username = new javax.swing.JLabel();
        Hi = new javax.swing.JLabel();
        karyawan = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        transaksi = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        order = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        barang = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        pembeli = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        riwayat = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        laporan = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        akun = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        konfigurasi = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        about = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        body = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Uzi Tailor");
        setName("main"); // NOI18N
        setUndecorated(true);

        Header.setBackground(new java.awt.Color(255, 255, 255));
        Header.setPreferredSize(new java.awt.Dimension(800, 50));
        Header.setLayout(new java.awt.BorderLayout());

        iconminmaxclose.setBackground(new java.awt.Color(5, 10, 46));
        iconminmaxclose.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Buttonclose.setBackground(new java.awt.Color(255, 255, 255));
        Buttonclose.setLayout(new java.awt.BorderLayout());

        close.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeMouseClicked(evt);
            }
        });
        Buttonclose.add(close, java.awt.BorderLayout.CENTER);

        iconminmaxclose.add(Buttonclose, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 50, 50));

        Buttonmax.setBackground(new java.awt.Color(255, 255, 255));
        Buttonmax.setLayout(new java.awt.BorderLayout());

        fullmax.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fullmax.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/fullscreen.png"))); // NOI18N
        fullmax.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fullmaxMouseClicked(evt);
            }
        });
        Buttonmax.add(fullmax, java.awt.BorderLayout.CENTER);

        iconminmaxclose.add(Buttonmax, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 50, 50));

        ButtonMin.setBackground(new java.awt.Color(255, 255, 255));
        ButtonMin.setLayout(new java.awt.BorderLayout());

        minimize.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        minimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/minimize.png"))); // NOI18N
        minimize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeMouseClicked(evt);
            }
        });
        ButtonMin.add(minimize, java.awt.BorderLayout.CENTER);

        iconminmaxclose.add(ButtonMin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 50, 50));

        Header.add(iconminmaxclose, java.awt.BorderLayout.LINE_END);

        title.setBackground(new java.awt.Color(217, 4, 41));
        title.setPreferredSize(new java.awt.Dimension(150, 50));
        title.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Staatliches", 0, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("uzi tailor");
        title.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 15, -1, -1));

        Header.add(title, java.awt.BorderLayout.LINE_START);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 5, 15));

        username.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setText("Hello");
        jPanel1.add(username);

        Hi.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        Hi.setText("Hello");
        jPanel1.add(Hi);

        karyawan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        karyawan.setText("Uzi Tailor");
        jPanel1.add(karyawan);

        Header.add(jPanel1, java.awt.BorderLayout.CENTER);

        getContentPane().add(Header, java.awt.BorderLayout.PAGE_START);

        menu.setBackground(new java.awt.Color(43, 45, 66));
        menu.setPreferredSize(new java.awt.Dimension(150, 450));
        menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        transaksi.setBackground(new java.awt.Color(65, 68, 96));
        transaksi.setPreferredSize(new java.awt.Dimension(150, 40));
        transaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                transaksiMouseClicked(evt);
            }
        });
        transaksi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/transaksi.png"))); // NOI18N
        transaksi.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, -1, -1));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Transaksi");
        transaksi.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(transaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, -1, -1));

        order.setBackground(new java.awt.Color(43, 45, 66));
        order.setPreferredSize(new java.awt.Dimension(150, 40));
        order.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                orderMouseClicked(evt);
            }
        });
        order.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/proses.png"))); // NOI18N
        order.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 12, -1, -1));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Order on Progress");
        order.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(order, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, -1, -1));

        barang.setBackground(new java.awt.Color(43, 45, 66));
        barang.setPreferredSize(new java.awt.Dimension(150, 40));
        barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                barangMouseClicked(evt);
            }
        });
        barang.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/barang.png"))); // NOI18N
        barang.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Master Barang");
        barang.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(barang, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, -1, -1));

        pembeli.setBackground(new java.awt.Color(43, 45, 66));
        pembeli.setPreferredSize(new java.awt.Dimension(150, 40));
        pembeli.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pembeliMouseClicked(evt);
            }
        });
        pembeli.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/akun.png"))); // NOI18N
        pembeli.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, -1, -1));

        jLabel19.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Data Pembeli");
        pembeli.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(pembeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, -1, -1));

        riwayat.setBackground(new java.awt.Color(43, 45, 66));
        riwayat.setPreferredSize(new java.awt.Dimension(150, 40));
        riwayat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                riwayatMouseClicked(evt);
            }
        });
        riwayat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/riwayat.png"))); // NOI18N
        riwayat.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 12, -1, -1));

        jLabel9.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Riwayat Transaksi");
        riwayat.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(riwayat, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, -1, -1));

        laporan.setBackground(new java.awt.Color(43, 45, 66));
        laporan.setPreferredSize(new java.awt.Dimension(150, 40));
        laporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                laporanMouseClicked(evt);
            }
        });
        laporan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/laporan.png"))); // NOI18N
        laporan.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, -1, -1));

        jLabel11.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Laporan Penjualan");
        laporan.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(laporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, -1, -1));

        akun.setBackground(new java.awt.Color(43, 45, 66));
        akun.setPreferredSize(new java.awt.Dimension(150, 40));
        akun.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                akunMouseClicked(evt);
            }
        });
        akun.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/akun.png"))); // NOI18N
        akun.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, -1, -1));

        jLabel13.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Master Akun");
        akun.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(akun, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, -1, -1));

        konfigurasi.setBackground(new java.awt.Color(43, 45, 66));
        konfigurasi.setPreferredSize(new java.awt.Dimension(150, 40));
        konfigurasi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/konfigurasi.png"))); // NOI18N
        konfigurasi.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, -1, -1));

        jLabel15.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Konfigurasi");
        konfigurasi.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(konfigurasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, -1, -1));

        about.setBackground(new java.awt.Color(43, 45, 66));
        about.setPreferredSize(new java.awt.Dimension(150, 40));
        about.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aboutMouseClicked(evt);
            }
        });
        about.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/about.png"))); // NOI18N
        about.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 12, -1, -1));

        jLabel17.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("About US");
        about.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(47, 12, -1, -1));

        menu.add(about, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, -1, -1));

        getContentPane().add(menu, java.awt.BorderLayout.LINE_START);

        body.setBackground(new java.awt.Color(255, 255, 255));
        body.setPreferredSize(new java.awt.Dimension(874, 526));
        body.setLayout(new java.awt.BorderLayout());
        getContentPane().add(body, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeMouseClicked
        int Pilih = JOptionPane.showConfirmDialog(null,"Apakah yakin ingin logout ?","Peringatan",JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (Pilih == JOptionPane.OK_OPTION) {
            dispose();
            login logout = new login();
            logout.setVisible(true);
        }
    }//GEN-LAST:event_closeMouseClicked

    private void fullmaxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fullmaxMouseClicked
        if(this.getExtendedState()!= main.MAXIMIZED_BOTH){
            this.setExtendedState(main.MAXIMIZED_BOTH);
        }
        else{
            this.setExtendedState(main.NORMAL);
        }
    }//GEN-LAST:event_fullmaxMouseClicked

    private void minimizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeMouseClicked
        if(this.getExtendedState()!= main.ICONIFIED){
            this.setExtendedState(main.ICONIFIED);
        }
        else{
            this.setExtendedState(main.NORMAL);
        }
    }//GEN-LAST:event_minimizeMouseClicked

    private void barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barangMouseClicked
        barang.setBackground(new Color(65,68,96));
        transaksi.setBackground(new Color(43,45,66));
        order.setBackground(new Color(43,45,66));
        pembeli.setBackground(new Color(43,45,66));
        riwayat.setBackground(new Color(43,45,66));
        laporan.setBackground(new Color(43,45,66));
        akun.setBackground(new Color(43,45,66));
        konfigurasi.setBackground(new Color(43,45,66));
        about.setBackground(new Color(43,45,66));
        body.removeAll();
        body.add(new PanelSwaper(new barang(this)));
        body.updateUI();
    }//GEN-LAST:event_barangMouseClicked

    private void akunMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_akunMouseClicked
        akun.setBackground(new Color(65,68,96));
        transaksi.setBackground(new Color(43,45,66));
        order.setBackground(new Color(43,45,66));
        barang.setBackground(new Color(43,45,66));
        pembeli.setBackground(new Color(43,45,66));
        riwayat.setBackground(new Color(43,45,66));
        laporan.setBackground(new Color(43,45,66));
        konfigurasi.setBackground(new Color(43,45,66));
        about.setBackground(new Color(43,45,66));
        body.removeAll();
        body.add(new PanelSwaper(new akun(this)));
        body.updateUI();
    }//GEN-LAST:event_akunMouseClicked

    private void riwayatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_riwayatMouseClicked
        riwayat.setBackground(new Color(65,68,96));
        transaksi.setBackground(new Color(43,45,66));
        order.setBackground(new Color(43,45,66));
        barang.setBackground(new Color(43,45,66));
        pembeli.setBackground(new Color(43,45,66));
        laporan.setBackground(new Color(43,45,66));
        akun.setBackground(new Color(43,45,66));
        konfigurasi.setBackground(new Color(43,45,66));
        about.setBackground(new Color(43,45,66));
        body.removeAll();
        body.add(new PanelSwaper(new riwayat(this)));
        body.updateUI();
    }//GEN-LAST:event_riwayatMouseClicked

    private void laporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_laporanMouseClicked
        laporan.setBackground(new Color(65,68,96));
        transaksi.setBackground(new Color(43,45,66));
        order.setBackground(new Color(43,45,66));
        barang.setBackground(new Color(43,45,66));
        pembeli.setBackground(new Color(43,45,66));
        riwayat.setBackground(new Color(43,45,66));
        akun.setBackground(new Color(43,45,66));
        konfigurasi.setBackground(new Color(43,45,66));
        about.setBackground(new Color(43,45,66));
        body.removeAll();
        body.add(new PanelSwaper(new laporan(this)));
        body.updateUI();
    }//GEN-LAST:event_laporanMouseClicked

    private void aboutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aboutMouseClicked
        
    }//GEN-LAST:event_aboutMouseClicked

    private void orderMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orderMouseClicked
        order.setBackground(new Color(65,68,96));
        transaksi.setBackground(new Color(43,45,66));
        barang.setBackground(new Color(43,45,66));
        pembeli.setBackground(new Color(43,45,66));
        riwayat.setBackground(new Color(43,45,66));
        laporan.setBackground(new Color(43,45,66));
        akun.setBackground(new Color(43,45,66));
        konfigurasi.setBackground(new Color(43,45,66));
        about.setBackground(new Color(43,45,66));
        body.removeAll();
        body.add(new PanelSwaper(new order(this)));
        body.updateUI();
    }//GEN-LAST:event_orderMouseClicked

    private void pembeliMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pembeliMouseClicked
        pembeli.setBackground(new Color(65,68,96));
        transaksi.setBackground(new Color(43,45,66));
        order.setBackground(new Color(43,45,66));
        barang.setBackground(new Color(43,45,66));
        riwayat.setBackground(new Color(43,45,66));
        laporan.setBackground(new Color(43,45,66));
        akun.setBackground(new Color(43,45,66));
        konfigurasi.setBackground(new Color(43,45,66));
        about.setBackground(new Color(43,45,66));
        body.removeAll();
        body.add(new PanelSwaper(new pembeli(this)));
        body.updateUI();
    }//GEN-LAST:event_pembeliMouseClicked

    private void transaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_transaksiMouseClicked
        transaksi.setBackground(new Color(65,68,96));
        order.setBackground(new Color(43,45,66));
        barang.setBackground(new Color(43,45,66));
        pembeli.setBackground(new Color(43,45,66));
        riwayat.setBackground(new Color(43,45,66));
        laporan.setBackground(new Color(43,45,66));
        akun.setBackground(new Color(43,45,66));
        konfigurasi.setBackground(new Color(43,45,66));
        about.setBackground(new Color(43,45,66));
        body.removeAll();
        body.add(new PanelSwaper(new transaksi(this)));
        body.updateUI();
    }//GEN-LAST:event_transaksiMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ButtonMin;
    private javax.swing.JPanel Buttonclose;
    private javax.swing.JPanel Buttonmax;
    private javax.swing.JPanel Header;
    public javax.swing.JLabel Hi;
    private javax.swing.JPanel about;
    private javax.swing.JPanel akun;
    private javax.swing.JPanel barang;
    private javax.swing.JPanel body;
    private javax.swing.JLabel close;
    private javax.swing.JLabel fullmax;
    private javax.swing.JPanel iconminmaxclose;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JLabel karyawan;
    private javax.swing.JPanel konfigurasi;
    private javax.swing.JPanel laporan;
    private javax.swing.JPanel menu;
    private javax.swing.JLabel minimize;
    private javax.swing.JPanel order;
    private javax.swing.JPanel pembeli;
    private javax.swing.JPanel riwayat;
    private javax.swing.JPanel title;
    private javax.swing.JPanel transaksi;
    public javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
