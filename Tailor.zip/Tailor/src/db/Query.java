package db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import model.account;

public class Query {
    static Connection c = new Connection();
    
    public boolean login(String username, String password) {
        boolean login = false;
        try {
            c.getDBConn();
            String sql = "SELECT `username`, `password`, `level` FROM karyawan WHERE `username` =? AND password =?";
            PreparedStatement ps = c.getCon().prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                if(password.equals(rs.getString("password"))) {
                    if(rs.getString("level").equals("Admin")) {
                        login = true;
                    } else if (rs.getString("level").equals("Karyawan")) {
                        login = true;
                    }
                } else {
                    login = false;
                }
            } else {
                login = false;
            }
            c.closeConnection();
        } catch (Exception e2) {
            e2.printStackTrace();
            System.out.println(e2);
        }
        return login;
    }
    
    public static ArrayList<account> getAkun() {
        try {
            ArrayList<account> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT `username`, `nama_karyawan`, `alamat_karyawan`, `jenis_kelamin`, `no_hp`, `level` FROM karyawan;";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                account A = new account();
                A.setUsername(rst.getString("username"));
                A.setNama(rst.getString("nama_karyawan"));
                A.setAlamat(rst.getString("alamat_karyawan"));
                A.setKelamin(rst.getString("jenis_kelamin"));
                A.setHp(rst.getString("no_hp"));
                A.setJabatan(rst.getString("level"));
                list.add(A);

            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
}
