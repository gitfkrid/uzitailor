package db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Laporan;
import model.Riwayat;
import model.account;
import model.addAccount;
import model.masterBarang;

public class Query {
    static Connection c = new Connection();
    
    /* QUERY LOGIN */
    public boolean login(String username, String password) {
        boolean login = false;
        try {
            c.getDBConn();
            String sql = "SELECT `username`, `password`, `level` FROM karyawan WHERE `username` =? AND password =?";
            PreparedStatement ps = c.getCon().prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                if(password.equals(rs.getString("password"))) {
                    if(rs.getString("level").equals("Admin")) {
                        login = true;
                    } else if (rs.getString("level").equals("Karyawan")) {
                        login = true;
                    }
                } else {
                    login = false;
                }
            } else {
                login = false;
            }
            c.closeConnection();
        } catch (Exception e2) {
            e2.printStackTrace();
            System.out.println(e2);
        }
        return login;
    }
    
    /* QUERY BARANG */
    public static ArrayList<masterBarang> getBarang() {
        try {
            ArrayList<masterBarang> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT * FROM master_barang";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                masterBarang A = new masterBarang();
                A.setNama(rst.getString("nama_barang"));
                A.setKode(rst.getString("kode_barang"));
                A.setLebar_dada(rst.getString("lebar_dada"));
                A.setPanjang_pakaian(rst.getString("panjang_pakaian"));
                A.setLebar_panggul(rst.getString("lebar_panggul"));
                A.setLingkar_panggul(rst.getString("lingkar_panggul"));               
                A.setLingkar_pinggang(rst.getString("lingkar_pinggang"));
                A.setPanjang_tangan(rst.getString("panjang_tangan"));
                A.setPanjang_celana(rst.getString("panjang_celana"));
                A.setLingkar_dada(rst.getString("lingkar_dada"));
                A.setLingkar_perut(rst.getString("lingkar_perut"));
                A.setLebar_pinggul(rst.getString("lebar_pinggul"));                
                A.setLingkar_punggung(rst.getString("lingkar_punggung"));
                A.setLingkar_lengan(rst.getString("lingkar_lengan"));
                A.setSet_lingkar_lengan(rst.getString("set_lingkar_lengan"));
                A.setLebar_pundak(rst.getString("lebar_pundak"));
                A.setLebar_badan(rst.getString("lebar_badan"));
                A.setSet_lingkar_lengan(rst.getString("set_lingkar_lengan"));              
                A.setPanjang_Lengan(rst.getString("panjang_lengan"));
                A.setTinggi_leher(rst.getString("tinggi_leher"));
                A.setLebar_bawah(rst.getString("lebar_bawah"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    public static void addBarang(masterBarang A) {
        try {
            String sql = "INSERT INTO master_barang VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            c.getDBConn();
            PreparedStatement st = c.getCon().prepareStatement(sql);
            st.setString(1, A.getNama());
            st.setString(2, A.getKode());
            st.setString(3, A.getLebar_dada());
            st.setString(4, A.getPanjang_pakaian());
            st.setString(5, A.getLebar_panggul());
            st.setString(6, A.getLingkar_panggul());
            st.setString(7, A.getLingkar_pinggang());            
            st.setString(8, A.getPanjang_tangan());
            st.setString(9, A.getPanjang_celana());
            st.setString(10, A.getLingkar_dada());
            st.setString(11, A.getLingkar_perut());
            st.setString(12, A.getLebar_pinggul());
            st.setString(13, A.getLingkar_punggung());
            st.setString(14, A.getLingkar_lengan());            
            st.setString(15, A.getSet_lingkar_badan());
            st.setString(16, A.getLebar_pundak());
            st.setString(17, A.getLebar_badan());
            st.setString(18, A.getSet_lingkar_lengan());
            st.setString(19, A.getPanjang_lengan());            
            st.setString(20, A.getTinggi_leher());            
            st.setString(21, A.getLebar_bawah());            
            st.executeUpdate();
            st.close();
            c.closeConnection();
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
    }
    
    public static void editBarang(masterBarang A) {
        try {
            String sql = "UPDATE `master_barang` SET "
            +"`nama_barang`='"+A.getNama()
            +"', `kode_barang`='"+A.getKode()
            +"',`lebar_dada`='"+A.getLebar_dada()
            +"',`panjang_pakaian`='"+A.getPanjang_pakaian()
            +"',`lebar_panggul`='"+A.getLebar_panggul()
            +"',`lingkar_panggul`='"+A.getLingkar_panggul()
            +"',`lingkar_pinggang`='"+A.getLingkar_pinggang()
            +"',`panjang_tangan`='"+A.getPanjang_tangan()
            +"',`panjang_celana`='"+A.getPanjang_celana()
            +"',`lingkar_dada`='"+A.getLingkar_dada()
            +"',`lingkar_perut`='"+A.getLingkar_perut()
            +"',`lebar_pinggul`='"+A.getLebar_pinggul()
            +"',`lingkar_punggung`='"+A.getLingkar_punggung()
            +"',`lingkar_lengan`='"+A.getLingkar_lengan()
            +"',`set_lingkar_badan`='"+A.getSet_lingkar_badan()
            +"',`lebar_pundak`='"+A.getLebar_pundak()
            +"',`lebar_badan`='"+A.getLebar_badan()
            +"',`set_lingkar_lengan`='"+A.getSet_lingkar_lengan()
            +"',`panjang_lengan`='"+A.getPanjang_lengan()
            +"',`tinggi_leher`='"+A.getTinggi_leher()
            +"',`lebar_bawah`='"+A.getLebar_bawah()
            + "' WHERE kode_barang='"+A.getKode()+"'";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            st.executeUpdate(sql);
            st.close();
            c.closeConnection();
        } catch (SQLException ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
    }
    
    public void deleteBarang(String Kode) {
        try {
            c.getDBConn();
            java.sql.PreparedStatement ps = c.getCon().prepareStatement("DELETE FROM master_barang WHERE kode_barang=?;");
            ps.setString(1, Kode);
            ps.execute();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /* QUERY RIWAYAT */
    public static ArrayList<Riwayat> getRiwayat() {
        try {
            ArrayList<Riwayat> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT detail_transaksi.kode_transaksi, kode_barang, qty, karyawan, id_pembeli , waktu, transaksi.total FROM detail_transaksi JOIN transaksi ON transaksi.kode_transaksi=detail_transaksi.kode_transaksi";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Riwayat A = new Riwayat();
                A.setKode_transaksi(rst.getString("detail_transaksi.kode_transaksi"));
                A.setKode_barang(rst.getString("kode_barang"));
                A.setQty(rst.getString("qty"));
                A.setKaryawan(rst.getString("karyawan"));
                A.setPembeli(rst.getString("id_pembeli"));
                A.setWaktu(rst.getString("waktu"));
                A.setTotal(rst.getString("transaksi.total"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY LAPORAN */
    public static ArrayList<Laporan> getLaporan() {
        try {
            ArrayList<Laporan> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT waktu, kode_transaksi, total FROM transaksi;";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Laporan A = new Laporan();
                A.setWaktu(rst.getString("waktu"));
                A.setTransaksi(rst.getString("kode_transaksi"));
                A.setTotal(rst.getString("total"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY AKUN */
    public static ArrayList<account> getAkun() {
        try {
            ArrayList<account> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT * FROM karyawan WHERE level='" + "Karyawan'";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                account A = new account();
                A.setUsername(rst.getString("username"));
                A.setNama(rst.getString("nama_karyawan"));
                A.setAlamat(rst.getString("alamat_karyawan"));
                A.setKelamin(rst.getString("jenis_kelamin"));
                A.setHp(rst.getString("no_hp"));
                A.setJabatan(rst.getString("level"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    public static void addAccount(addAccount A) {
        try {
            String sql = "INSERT INTO karyawan (username, nama_karyawan, alamat_karyawan, jenis_kelamin, no_hp, foto_profil, password, level) VALUES (?,?,?,?,?,?,?,?)";
            c.getDBConn();
            PreparedStatement st = c.getCon().prepareStatement(sql);
            st.setString(1, A.getUsername());
            st.setString(2, A.getNama());
            st.setString(3, A.getAlamat());
            st.setString(4, A.getKelamin());
            st.setString(5, A.getHp());
            st.setBlob(6, A.getProfile());
            st.setString(7, A.getPassword());
            st.setString(8, A.getJabatan());            
            st.executeUpdate();
            st.close();
            c.closeConnection();
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
    }
    
    public void deleteAkun(String id) {
        try {
            c.getDBConn();
            java.sql.PreparedStatement ps = c.getCon().prepareStatement("DELETE FROM karyawan WHERE username=?;");
            ps.setString(1, id);
            ps.execute();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
