package db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import model.Laporan;
import model.Login;
import model.Order;
import model.Pembeli;
import model.Riwayat;
import model.Transaksi;
import model.Account;
import model.Account;
import model.masterBarang;

public class Query {
    static Connection c = new Connection();
    
    /* QUERY LOGIN */
    public boolean login(String username, String password) {
        boolean login = false;
        try {
            c.getDBConn();
            String sql = "SELECT `username`, `password`, `level` FROM karyawan WHERE `username` =? AND password =?";
            PreparedStatement ps = c.getCon().prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                if(password.equals(rs.getString("password"))) {
                    if(rs.getString("level").equals("Admin")) {
                        login = true;
                    } else if (rs.getString("level").equals("Karyawan")) {
                        login = true;
                    }
                } else {
                    login = false;
                }
            } else {
                login = false;
            }
            c.closeConnection();
        } catch (Exception e2) {
            e2.printStackTrace();
            System.out.println(e2);
        }
        return login;
    }
    public static ArrayList<Login> getLogin(String username, String password) {
        try {
            ArrayList<Login> list = new ArrayList<>();
            String query = "SELECT `username`, `nama_karyawan`, `password`, `level` FROM karyawan WHERE `username` =? AND password =?";
            c.getDBConn();
            PreparedStatement ps = c.getCon().prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Login A = new Login();
                A.setUsername(rs.getString("username"));
                A.setNama(rs.getString("nama_karyawan"));
                A.setPassword(rs.getString("password"));
                A.setLevel(rs.getString("level"));
                list.add(A);
            }
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY TRANSAKSI */
    public static ArrayList<Transaksi> getNotrx() {
        try {
            ArrayList<Transaksi> list = new ArrayList<>();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMyy");
            LocalDate localDate = LocalDate.now();
            String now = dtf.format(localDate);
            Transaksi A = new Transaksi();
            ResultSet rst;
            String query = "SELECT * FROM transaksi WHERE kode_transaksi IN(SELECT MAX(kode_transaksi) FROM transaksi) ORDER BY kode_transaksi DESC";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            if(rst.next()) {
                if(rst.getString("kode_transaksi").substring(0,6).equals(now)) {
                    int notrx = Integer.parseInt(rst.getString("kode_transaksi"));
                    notrx = notrx + 1;
                    A.setNo_transaksi(String.valueOf(notrx));
                    list.add(A);  
                } else {
                    A.setNo_transaksi(now + "001");
                    list.add(A);
                }
            } else {
                A.setNo_transaksi(now + "001");
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    public static ArrayList<Transaksi> getkodebarang(String kode_barang) {
        try {
            ArrayList<Transaksi> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT `kode_barang`, `nama_barang` FROM master_barang WHERE kode_barang='" + kode_barang + "'";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            Transaksi A = new Transaksi();
            if (rst.next()) {
                A.setKode_barang(rst.getString("kode_barang"));
                A.setNama_barang(rst.getString("nama_barang"));
                list.add(A);
            } else {
                A.setKode_barang("EROR");
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY ORDER ON PROGRESS */
    public static ArrayList<Order> getOrder() {
        try {
            ArrayList<Order> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT transaksi.kode_transaksi, transaksi.waktu, tanggal_jadi, status_transaksi FROM status JOIN transaksi ON transaksi.kode_transaksi=status.kode_transaksi";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Order A = new Order();
                A.setKode_transaksi(rst.getString("transaksi.kode_transaksi"));
                A.setBeli(rst.getDate("transaksi.waktu"));
                A.setJadi(rst.getDate("tanggal_jadi"));
                A.setStatus(rst.getString("status_transaksi"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY BARANG */
    public static ArrayList<masterBarang> getBarang() {
        try {
            ArrayList<masterBarang> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT * FROM master_barang";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                masterBarang A = new masterBarang();
                A.setNama(rst.getString("nama_barang"));
                A.setKode(rst.getString("kode_barang"));
                A.setLebar_dada(rst.getString("lebar_dada"));
                A.setPanjang_pakaian(rst.getString("panjang_pakaian"));
                A.setLebar_panggul(rst.getString("lebar_panggul"));
                A.setLingkar_panggul(rst.getString("lingkar_panggul"));               
                A.setLingkar_pinggang(rst.getString("lingkar_pinggang"));
                A.setPanjang_tangan(rst.getString("panjang_tangan"));
                A.setPanjang_celana(rst.getString("panjang_celana"));
                A.setLingkar_dada(rst.getString("lingkar_dada"));
                A.setLingkar_perut(rst.getString("lingkar_perut"));
                A.setLebar_pinggul(rst.getString("lebar_pinggul"));                
                A.setLingkar_punggung(rst.getString("lingkar_punggung"));
                A.setLingkar_lengan(rst.getString("lingkar_lengan"));
                A.setSet_lingkar_lengan(rst.getString("set_lingkar_lengan"));
                A.setLebar_pundak(rst.getString("lebar_pundak"));
                A.setLebar_badan(rst.getString("lebar_badan"));
                A.setSet_lingkar_lengan(rst.getString("set_lingkar_lengan"));              
                A.setPanjang_Lengan(rst.getString("panjang_lengan"));
                A.setTinggi_leher(rst.getString("tinggi_leher"));
                A.setLebar_bawah(rst.getString("lebar_bawah"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    public static void addBarang(masterBarang A) {
        try {
            String sql = "INSERT INTO master_barang VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            c.getDBConn();
            PreparedStatement st = c.getCon().prepareStatement(sql);
            st.setString(1, A.getNama());
            st.setString(2, A.getKode());
            st.setString(3, A.getLebar_dada());
            st.setString(4, A.getPanjang_pakaian());
            st.setString(5, A.getLebar_panggul());
            st.setString(6, A.getLingkar_panggul());
            st.setString(7, A.getLingkar_pinggang());            
            st.setString(8, A.getPanjang_tangan());
            st.setString(9, A.getPanjang_celana());
            st.setString(10, A.getLingkar_dada());
            st.setString(11, A.getLingkar_perut());
            st.setString(12, A.getLebar_pinggul());
            st.setString(13, A.getLingkar_punggung());
            st.setString(14, A.getLingkar_lengan());            
            st.setString(15, A.getSet_lingkar_badan());
            st.setString(16, A.getLebar_pundak());
            st.setString(17, A.getLebar_badan());
            st.setString(18, A.getSet_lingkar_lengan());
            st.setString(19, A.getPanjang_lengan());            
            st.setString(20, A.getTinggi_leher());            
            st.setString(21, A.getLebar_bawah());            
            st.executeUpdate();
            st.close();
            c.closeConnection();
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
    }
    
    public static void editBarang(masterBarang A) {
        try {
            String sql = "UPDATE `master_barang` SET "
            +"`nama_barang`='"+A.getNama()
            +"', `kode_barang`='"+A.getKode()
            +"',`lebar_dada`='"+A.getLebar_dada()
            +"',`panjang_pakaian`='"+A.getPanjang_pakaian()
            +"',`lebar_panggul`='"+A.getLebar_panggul()
            +"',`lingkar_panggul`='"+A.getLingkar_panggul()
            +"',`lingkar_pinggang`='"+A.getLingkar_pinggang()
            +"',`panjang_tangan`='"+A.getPanjang_tangan()
            +"',`panjang_celana`='"+A.getPanjang_celana()
            +"',`lingkar_dada`='"+A.getLingkar_dada()
            +"',`lingkar_perut`='"+A.getLingkar_perut()
            +"',`lebar_pinggul`='"+A.getLebar_pinggul()
            +"',`lingkar_punggung`='"+A.getLingkar_punggung()
            +"',`lingkar_lengan`='"+A.getLingkar_lengan()
            +"',`set_lingkar_badan`='"+A.getSet_lingkar_badan()
            +"',`lebar_pundak`='"+A.getLebar_pundak()
            +"',`lebar_badan`='"+A.getLebar_badan()
            +"',`set_lingkar_lengan`='"+A.getSet_lingkar_lengan()
            +"',`panjang_lengan`='"+A.getPanjang_lengan()
            +"',`tinggi_leher`='"+A.getTinggi_leher()
            +"',`lebar_bawah`='"+A.getLebar_bawah()
            + "' WHERE kode_barang='"+A.getKode()+"'";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            st.executeUpdate(sql);
            st.close();
            c.closeConnection();
        } catch (SQLException ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
    }
    
    public void deleteBarang(String Kode) {
        try {
            c.getDBConn();
            java.sql.PreparedStatement ps = c.getCon().prepareStatement("DELETE FROM master_barang WHERE kode_barang=?;");
            ps.setString(1, Kode);
            ps.execute();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /* QUERY PEMBELI */
    public static ArrayList<Pembeli> getPembeli() {
        try {
            ArrayList<Pembeli> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT `nama_pembeli`, `alamat`, `no_hp`, `pembelian_ke` FROM `data_pembeli`";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Pembeli A = new Pembeli();
                A.setNama(rst.getString("nama_pembeli"));
                A.setAlamat(rst.getString("alamat"));
                A.setHp(rst.getString("no_hp"));
                A.setPembelian(rst.getInt("pembelian_ke"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY RIWAYAT */
    public static ArrayList<Riwayat> getRiwayat() {
        try {
            ArrayList<Riwayat> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT detail_transaksi.kode_transaksi, kode_barang, qty, karyawan, id_pembeli , waktu, transaksi.total FROM detail_transaksi JOIN transaksi ON transaksi.kode_transaksi=detail_transaksi.kode_transaksi";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Riwayat A = new Riwayat();
                A.setKode_transaksi(rst.getString("detail_transaksi.kode_transaksi"));
                A.setKode_barang(rst.getString("kode_barang"));
                A.setQty(rst.getString("qty"));
                A.setKaryawan(rst.getString("karyawan"));
                A.setPembeli(rst.getString("id_pembeli"));
                A.setWaktu(rst.getString("waktu"));
                A.setTotal(rst.getDouble("transaksi.total"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY LAPORAN */
    public static ArrayList<Laporan> getLaporan() {
        try {
            ArrayList<Laporan> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT waktu, kode_transaksi, total FROM transaksi;";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Laporan A = new Laporan();
                A.setWaktu(rst.getDate("waktu"));
                A.setTransaksi(rst.getString("kode_transaksi"));
                A.setTotal(rst.getDouble("total"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    public static ArrayList<Laporan> setLaporan(String awal, String akhir) {
        try {
            Double GTotal = 0.00;
            ArrayList<Laporan> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT waktu, kode_transaksi, total FROM transaksi WHERE waktu BETWEEN '" + awal + " 00:00:00' AND '" + akhir + " 23:59:59';";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Laporan A = new Laporan();
                A.setWaktu(rst.getDate("waktu"));
                A.setTransaksi(rst.getString("kode_transaksi"));
                A.setTotal(rst.getDouble("total"));
                GTotal = GTotal + A.getTotal();
                A.setGTotal(GTotal);
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    /* QUERY AKUN */
    public static ArrayList<Account> getAkun() {
        try {
            ArrayList<Account> list = new ArrayList<>();
            ResultSet rst;
            String query = "SELECT * FROM karyawan WHERE level='" + "Karyawan'";
            c.getDBConn();
            Statement st = c.getCon().createStatement();
            rst = st.executeQuery(query);
            while (rst.next()) {
                Account A = new Account();
                A.setUsername(rst.getString("username"));
                A.setNama(rst.getString("nama_karyawan"));
                A.setAlamat(rst.getString("alamat_karyawan"));
                A.setKelamin(rst.getString("jenis_kelamin"));
                A.setHp(rst.getString("no_hp"));
                A.setJabatan(rst.getString("level"));
                list.add(A);
            }
            rst.close();
            st.close();
            c.closeConnection();
            return list;
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
        return null;
    }
    
    public static void addAccount(Account A) {
        try {
            String sql = "INSERT INTO karyawan (username, nama_karyawan, alamat_karyawan, jenis_kelamin, no_hp, foto_profil, password, level) VALUES (?,?,?,?,?,?,?,?)";
            c.getDBConn();
            PreparedStatement st = c.getCon().prepareStatement(sql);
            st.setString(1, A.getUsername());
            st.setString(2, A.getNama());
            st.setString(3, A.getAlamat());
            st.setString(4, A.getKelamin());
            st.setString(5, A.getHp());
            st.setBlob(6, A.getProfile());
            st.setString(7, A.getPassword());
            st.setString(8, A.getJabatan());            
            st.executeUpdate();
            st.close();
            c.closeConnection();
        } catch (Exception ex) {
            String err = ex.getMessage();
            System.out.println(err);
        }
    }
    
    public void deleteAkun(String id) {
        try {
            c.getDBConn();
            java.sql.PreparedStatement ps = c.getCon().prepareStatement("DELETE FROM karyawan WHERE username=?;");
            ps.setString(1, id);
            ps.execute();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
