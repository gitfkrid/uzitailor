package dialog;

import db.Query;
import static java.awt.Component.CENTER_ALIGNMENT;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import model.masterBarang;
import panel.transaksi;
import views.TableColumnAdjuster;

public class kodebarang extends javax.swing.JDialog {
    
    private Query query = new Query();
    private masterBarang Barang = new masterBarang();
    private ArrayList<masterBarang> list;
    DefaultTableModel tbl;
    
    private void alignCenter(int column) {
        
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);

        tb_kode_barang.getColumnModel().getColumn(column).setCellRenderer(renderer);
    }
    
    private void noTable() {
        int Baris = tbl.getRowCount();
        for (int a = 0; a < Baris; a++) {
            String nomor = String.valueOf(a + 1);
            tbl.setValueAt(nomor, a, 0);
        }
    }
    
    private void tbmodel() {
        JTableHeader header = tb_kode_barang.getTableHeader();
        header.setBackground(new java.awt.Color(217,4,41));
        header.setForeground(java.awt.Color.white);
        header.setFont(new Font("Poppins", Font.BOLD, 11));
        header.setAlignmentX(CENTER_ALIGNMENT);
    }

    public kodebarang(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        loadTable();
        tbmodel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        search_panel = new javax.swing.JPanel();
        txt_search = new javax.swing.JTextField();
        search_bar = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_kode_barang = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Uzi Tailor - Barang");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setPreferredSize(new java.awt.Dimension(600, 50));
        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 15));

        search_panel.setBackground(new java.awt.Color(255, 255, 255));
        search_panel.setPreferredSize(new java.awt.Dimension(200, 50));
        search_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_search.setBackground(new java.awt.Color(237, 242, 244));
        txt_search.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txt_search.setBorder(null);
        txt_search.setPreferredSize(new java.awt.Dimension(130, 20));
        txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_searchKeyReleased(evt);
            }
        });
        search_panel.add(txt_search, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 5, -1, -1));

        search_bar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/search.png"))); // NOI18N
        search_panel.add(search_bar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        jPanel4.add(search_panel);

        jPanel2.add(jPanel4, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel2, java.awt.BorderLayout.NORTH);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        tb_kode_barang.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        tb_kode_barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Username", "Nama Karyawan", "Alamat Karyawan", "Jenis Kelamin", "No HP", "Jabatan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tb_kode_barang.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tb_kode_barang.setRowHeight(20);
        tb_kode_barang.setSelectionBackground(new java.awt.Color(239, 35, 60));
        tb_kode_barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_kode_barangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb_kode_barang);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 580, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel1.add(jPanel3, java.awt.BorderLayout.CENTER);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_searchKeyReleased
        String text = txt_search.getText().trim();
        filterTable(text);
    }//GEN-LAST:event_txt_searchKeyReleased

    private void tb_kode_barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_kode_barangMouseClicked
        int row = tb_kode_barang.getSelectedRow();
            if (row != -1) {
                Object kode = tb_kode_barang.getValueAt(row, 2);
                Barang.setKode(kode.toString());
                transaksi.kode_barang.setText(kode.toString());
            }
        dispose();
    }//GEN-LAST:event_tb_kode_barangMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                kodebarang dialog = new kodebarang(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel search_bar;
    private javax.swing.JPanel search_panel;
    private javax.swing.JTable tb_kode_barang;
    private javax.swing.JTextField txt_search;
    // End of variables declaration//GEN-END:variables
    
    private void loadTable() {
        list = Query.getBarang();
        String[] heading = {"No","Nama Barang", "Kode Barang", "Lebar Dada", "Panjang Pakaian", "Lebar Panggul", "Lingkar Panggul", "Lingkar Pinggang", "Panjang Tangan", "Panjang Celana", "Lingkar Dada", "Lingkar Perut", "Lebar Pinggul", "Lingkar Punggung", "Lingkar Lengan", "Set Lingkar Badan", "Lebar Pundak", "Lebar Badan", "Set Lingkar Lengan", "Panjang Lengan", "Tinggi Leher", "Lebar Bawah"};
        tbl = new DefaultTableModel (null,heading);
        tb_kode_barang.setModel(tbl);
        tbl = (DefaultTableModel) tb_kode_barang.getModel();
        tbl.setRowCount(0);
        for(masterBarang l:list){
            tbl.addRow(new Object[]{"",l.getNama(), l.getKode(), l.getLebar_dada(),l.getPanjang_pakaian(), l.getLebar_panggul(), l.getLingkar_panggul(),l.getLingkar_pinggang(), l.getPanjang_tangan(), l.getPanjang_celana(), l.getLingkar_dada(), l.getLingkar_perut(), l.getLebar_pinggul(),l.getLingkar_punggung(), l.getLingkar_lengan(), l.getSet_lingkar_badan(),l.getLebar_pundak(), l.getLebar_badan(), l.getSet_lingkar_lengan(),l.getPanjang_lengan(), l.getTinggi_leher(), l.getLebar_bawah()});
        }
        noTable();
        alignCenter(0);
        for (int i = 3; i < 22; i++) {
            alignCenter(i);
        }
        TableColumnAdjuster fit = new TableColumnAdjuster(tb_kode_barang); 
        fit.adjustColumns();
    }
    
    private void filterTable(String text) { 
        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(((DefaultTableModel) tb_kode_barang.getModel()));
        if (text.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter(text));
        };
        tb_kode_barang.setRowSorter(sorter);
    }
}
