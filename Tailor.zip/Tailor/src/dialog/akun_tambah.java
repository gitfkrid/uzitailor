package dialog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import model.Account;
import db.Query;

public class akun_tambah extends javax.swing.JDialog {
    
    private File f;
    private String path;

    public akun_tambah(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_exit = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        id_pegawai = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nama_pegawai = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        pass = new javax.swing.JTextField();
        alamat = new javax.swing.JTextField();
        btn_batal = new javax.swing.JLabel();
        cewe = new javax.swing.JRadioButton();
        cowo = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();
        btn_browse = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        btn_tambah = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        hp = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(javax.swing.UIManager.getDefaults().getColor("controlLtHighlight"));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel1.setPreferredSize(new java.awt.Dimension(400, 500));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/close.png"))); // NOI18N
        btn_exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_exitMouseClicked(evt);
            }
        });
        jPanel1.add(btn_exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, -1, -1));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 20)); // NOI18N
        jLabel1.setText("Tambah Data Pegawai");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, -1, -1));

        id_pegawai.setBackground(new java.awt.Color(237, 242, 244));
        id_pegawai.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        id_pegawai.setToolTipText("");
        id_pegawai.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        id_pegawai.setPreferredSize(new java.awt.Dimension(130, 30));
        jPanel1.add(id_pegawai, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 119, -1, -1));

        jLabel2.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel2.setText("Id Pegawai");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 102, -1, -1));

        jLabel3.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel3.setText("Nama Pegawai");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 102, -1, -1));

        nama_pegawai.setBackground(new java.awt.Color(237, 242, 244));
        nama_pegawai.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        nama_pegawai.setToolTipText("");
        nama_pegawai.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        nama_pegawai.setPreferredSize(new java.awt.Dimension(190, 30));
        jPanel1.add(nama_pegawai, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 119, -1, -1));

        jLabel4.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel4.setText("Password");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 169, -1, -1));

        pass.setBackground(new java.awt.Color(237, 242, 244));
        pass.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        pass.setToolTipText("");
        pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        pass.setPreferredSize(new java.awt.Dimension(130, 30));
        jPanel1.add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 186, -1, -1));

        alamat.setBackground(new java.awt.Color(237, 242, 244));
        alamat.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        alamat.setToolTipText("");
        alamat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        alamat.setPreferredSize(new java.awt.Dimension(340, 30));
        jPanel1.add(alamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 253, -1, -1));

        btn_batal.setFont(new java.awt.Font("Poppins", 0, 11)); // NOI18N
        btn_batal.setText("Batal");
        btn_batal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_batalMouseClicked(evt);
            }
        });
        jPanel1.add(btn_batal, new org.netbeans.lib.awtextra.AbsoluteConstraints(227, 417, -1, -1));

        cewe.setBackground(new java.awt.Color(255, 255, 255));
        cewe.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        cewe.setText("Perempuan");
        jPanel1.add(cewe, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 361, -1, -1));

        cowo.setBackground(new java.awt.Color(255, 255, 255));
        cowo.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        cowo.setText("Laki - Laki");
        jPanel1.add(cowo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 329, -1, -1));

        jLabel6.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel6.setText("Alamat");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 236, -1, -1));

        btn_browse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_upload.png"))); // NOI18N
        btn_browse.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(141, 153, 174), 1, true));
        btn_browse.setPreferredSize(new java.awt.Dimension(220, 50));
        btn_browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_browseActionPerformed(evt);
            }
        });
        jPanel1.add(btn_browse, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 331, -1, -1));

        jLabel7.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel7.setText("Jenis Kelamin");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 303, -1, -1));

        btn_tambah.setBackground(new java.awt.Color(255, 255, 255));
        btn_tambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_tambah.png"))); // NOI18N
        btn_tambah.setBorder(null);
        btn_tambah.setPreferredSize(new java.awt.Dimension(90, 30));
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });
        jPanel1.add(btn_tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 410, -1, -1));

        jLabel8.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel8.setText("Foto Profile");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 303, -1, -1));

        jLabel5.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        jLabel5.setText("No HP");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 169, -1, -1));

        hp.setBackground(new java.awt.Color(237, 242, 244));
        hp.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        hp.setToolTipText("");
        hp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        hp.setPreferredSize(new java.awt.Dimension(190, 30));
        jPanel1.add(hp, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 186, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_exitMouseClicked
        dispose();
    }//GEN-LAST:event_btn_exitMouseClicked

    private void btn_batalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_batalMouseClicked
        dispose();
    }//GEN-LAST:event_btn_batalMouseClicked

    private void btn_browseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_browseActionPerformed
        JFileChooser img = new JFileChooser();
        FileNameExtensionFilter fname = new FileNameExtensionFilter("PNG JPG AND JPEG", "png", "jpeg", "jpg");
        img.addChoosableFileFilter(fname);
        int load = img.showOpenDialog(null);

        if(load == img.APPROVE_OPTION) {
            f = img.getSelectedFile();
            path = f.getAbsolutePath();
        }
    }//GEN-LAST:event_btn_browseActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        Account A = new Account();
        File f = new File(path);
        String jk = null;
        if (cowo.isSelected()) {
                jk = "Laki - Laki";
            } else if (cewe.isSelected()) {
                jk = "Perempuan";
            }
        String level = "Karyawan";
        try {
            InputStream IS = new FileInputStream(f);
            A.setUsername(id_pegawai.getText());
            A.setNama(nama_pegawai.getText());
            A.setAlamat(alamat.getText());
            A.setKelamin(jk);
            A.setHp(hp.getText());
            A.setProfile(IS);
            A.setPassword(pass.getText());
            A.setJabatan(level);
            Query.addAccount(A);
            dispose();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(akun_tambah.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btn_tambahActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(akun_tambah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(akun_tambah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(akun_tambah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(akun_tambah.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                akun_tambah dialog = new akun_tambah(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alamat;
    private javax.swing.JLabel btn_batal;
    private javax.swing.JButton btn_browse;
    private javax.swing.JLabel btn_exit;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JRadioButton cewe;
    private javax.swing.JRadioButton cowo;
    private javax.swing.JTextField hp;
    private javax.swing.JTextField id_pegawai;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField nama_pegawai;
    private javax.swing.JTextField pass;
    // End of variables declaration//GEN-END:variables
}
