package model;

import java.util.Date;
import java.util.Objects;

public class Order {
    private String Kode_transaksi;
    private Date Beli;
    private Date Jadi;
    private String Status;
    
    public Order() {
        
    }
    
    public String getKode_transaksi() {
        return Kode_transaksi;
    }

    public void setKode_transaksi(String Kode_transaksi) {
        this.Kode_transaksi = Kode_transaksi;
    }
    
    public Date getBeli() {
        return Beli;
    }

    public void setBeli(Date Beli) {
        this.Beli = Beli;
    }
    
    public Date getJadi() {
        return Jadi;
    }

    public void setJadi(Date Jadi) {
        this.Jadi = Jadi;
    }
    
    public String getStatus() {
        return Status;
    }
    
    public void setStatus(String Status) {
        this.Status = Status;
    }
    
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Order other = (Order) obj;
        if (!Objects.equals(this.Kode_transaksi, other.Kode_transaksi)) {
            return false;
        }
        if (!Objects.equals(this.Beli, other.Beli)) {
            return false;
        }
        if (!Objects.equals(this.Jadi, other.Jadi)) {
            return false;
        }
        if (!Objects.equals(this.Status, other.Status)) {
            return false;
        }
        return true;
    }
}
