package model;

import java.util.Objects;

public class masterBarang {
    private String Kode;
    private String Nama;
    private String Lebar_dada;
    private String Panjang_pakaian;
    private String Lebar_panggul;
    private String Lingkar_panggul;
    private String Lingkar_pinggang;
    private String Panjang_tangan;
    private String Panjang_celana;
    private String Lingkar_dada;
    private String Lingkar_perut;
    private String Lebar_pinggul;
    private String Lingkar_punggung;
    private String Lingkar_lengan;
    private String Set_lingkar_badan;
    private String Lebar_pundak;
    private String Lebar_badan;
    private String Set_lingkar_lengan;
    private String Panjang_lengan;
    private String Tinggi_leher;
    private String Lebar_bawah;
    
    public masterBarang() {
        
    }
    
    public String getKode() {
        return Kode;
    }

    public void setKode(String Kode) {
        this.Kode = Kode;
    }
    
    public String getNama() {
        return Nama;
    }
    
    public void setNama(String Nama) {
        this.Nama = Nama;
    }
    
    public String getLebar_dada() {
        return Lebar_dada;
    }
    
    public void setLebar_dada(String Lebar_dada) {
        this.Lebar_dada = Lebar_dada;
    }
    
    public String getPanjang_pakaian() {
        return Panjang_pakaian;
    }

    public void setPanjang_Pakaian(String Panjang_pakaian) {
        this.Panjang_pakaian = Panjang_pakaian;
    }
    
    public String getLebar_panggul() {
        return Lebar_panggul;
    }

    public void setLebar_panggul(String Lebar_panggul) {
        this.Lebar_panggul = Lebar_panggul;
    }
    
    public String getLingkar_panggul() {
        return Lingkar_panggul;
    }

    public void setLingkar_panggul(String Lingkar_panggul) {
        this.Lingkar_panggul = Lingkar_panggul;
    }
    
    public String getLingkar_pinggang() {
        return Lingkar_pinggang;
    }

    public void setLingkar_pinggang(String Lingkar_pinggang) {
        this.Lingkar_pinggang = Lingkar_pinggang;
    }
    
    public String getPanjang_tangan() {
        return Panjang_tangan;
    }

    public void setPanjang_tangan(String Panjang_tangan) {
        this.Panjang_tangan = Panjang_tangan;
    }
    
    public String getPanjang_celana() {
        return Panjang_celana;
    }

    public void setPanjang_celana(String Panjang_celana) {
        this.Panjang_celana = Panjang_celana;
    }
    
    public String getLingkar_dada() {
        return Lingkar_dada;
    }

    public void setLingkar_dada(String Lingkar_dada) {
        this.Lingkar_dada = Lingkar_dada;
    }
    
    public String getLingkar_perut() {
        return Lingkar_perut;
    }

    public void setLingkar_perut(String Lingkar_perut) {
        this.Lingkar_perut = Lingkar_perut;
    }
    
    public String getLebar_pinggul() {
        return Lebar_pinggul;
    }

    public void setLebar_pinggul(String Lebar_pinggul) {
        this.Lebar_pinggul = Lebar_pinggul;
    }
    
    public String getLingkar_punggung() {
        return Lingkar_punggung;
    }

    public void setLingkar_punggung(String Lingkar_punggung) {
        this.Lingkar_punggung = Lingkar_punggung;
    }
    
    public String getLingkar_lengan() {
        return Lingkar_lengan;
    }

    public void setLingkar_lengan(String Lingkar_lengan) {
        this.Lingkar_lengan = Lingkar_lengan;
    }
    
    public String getSet_lingkar_badan() {
        return Set_lingkar_badan;
    }

    public void setSet_lingkar_badan(String Set_lingkar_badan) {
        this.Set_lingkar_badan = Set_lingkar_badan;
    }
    
    public String getLebar_pundak() {
        return Lebar_pundak;
    }

    public void setLebar_pundak(String Lebar_pundak) {
        this.Lebar_pundak = Lebar_pundak;
    }
    
    public String getLebar_badan() {
        return Lebar_badan;
    }

    public void setLebar_badan(String Lebar_badan) {
        this.Lebar_badan = Lebar_badan;
    }
    
    public String getSet_lingkar_lengan() {
        return Set_lingkar_lengan;
    }

    public void setSet_lingkar_lengan(String Set_lingkar_lengan) {
        this.Set_lingkar_lengan = Set_lingkar_lengan;
    }
    
    public String getPanjang_lengan() {
        return Panjang_lengan;
    }

    public void setPanjang_Lengan(String Panjang_lengan) {
        this.Panjang_lengan = Panjang_lengan;
    }
    
    public String getTinggi_leher() {
        return Tinggi_leher;
    }

    public void setTinggi_leher(String Tinggi_leher) {
        this.Tinggi_leher = Tinggi_leher;
    }
    
    public String getLebar_bawah() {
        return Lebar_bawah;
    }

    public void setLebar_bawah(String Lebar_bawah) {
        this.Lebar_bawah = Lebar_bawah;
    }
    
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final masterBarang other = (masterBarang) obj;
        if (!Objects.equals(this.Kode, other.Kode)) {
            return false;
        }
        if (!Objects.equals(this.Nama, other.Nama)) {
            return false;
        }
        if (!Objects.equals(this.Lebar_dada, other.Lebar_dada)) {
            return false;
        }
        if (!Objects.equals(this.Panjang_pakaian, other.Panjang_pakaian)) {
            return false;
        }
        if (!Objects.equals(this.Lebar_panggul, other.Lebar_panggul)) {
            return false;
        }
        if (!Objects.equals(this.Lingkar_panggul, other.Lingkar_panggul)) {
            return false;
        }
        if (!Objects.equals(this.Lingkar_pinggang, other.Lingkar_pinggang)) {
            return false;
        }
        if (!Objects.equals(this.Panjang_tangan, other.Panjang_tangan)) {
            return false;
        }
        if (!Objects.equals(this.Panjang_celana, other.Panjang_celana)) {
            return false;
        }
        if (!Objects.equals(this.Lingkar_dada, other.Lingkar_dada)) {
            return false;
        }
        if (!Objects.equals(this.Lingkar_perut, other.Lingkar_perut)) {
            return false;
        }
        if (!Objects.equals(this.Lebar_pinggul, other.Lebar_pinggul)) {
            return false;
        }
        if (!Objects.equals(this.Lingkar_punggung, other.Lingkar_punggung)) {
            return false;
        }
        if (!Objects.equals(this.Lingkar_lengan, other.Lingkar_lengan)) {
            return false;
        }
        if (!Objects.equals(this.Set_lingkar_lengan, other.Set_lingkar_lengan)) {
            return false;
        }
        if (!Objects.equals(this.Lebar_pundak, other.Lebar_pundak)) {
            return false;
        }
        if (!Objects.equals(this.Lebar_badan, other.Lebar_badan)) {
            return false;
        }
        if (!Objects.equals(this.Set_lingkar_lengan, other.Set_lingkar_lengan)) {
            return false;
        }
        if (!Objects.equals(this.Panjang_lengan, other.Panjang_lengan)) {
            return false;
        }
        if (!Objects.equals(this.Tinggi_leher, other.Tinggi_leher)) {
            return false;
        }
        if (!Objects.equals(this.Lebar_bawah, other.Lebar_bawah)) {
            return false;
        }
        return true;
    }
}