package model;

public class Login {
   private String Username;
   private String Nama;
   private String Password;
   private String Level;
   
   public Login() {
       
   }
   
   public String getUsername() {
       return Username;
   }
   
   public void setUsername(String Username) {
       this.Username = Username;
   }
   
   public String getNama() {
       return Nama;
   }
   
   public void setNama(String Nama) {
       this.Nama = Nama;
   }
   
   public String getPassword() {
       return Password;
   }
   
   public void setPassword(String Password) {
       this.Password = Password;
   }
   
   public String getLevel() {
       return Level;
   }
   
   public void setLevel(String Level) {
       this.Level = Level;
   }
}
