package model;

import java.util.Objects;

public class Riwayat {
    private String Kode_transaksi;
    private String Kode_barang;
    private String Qty;
    private String Karyawan;
    private String Pembeli;
    private String Waktu;
    private Double Total;
    
    public Riwayat() {
        
    }
    
    public String getKode_transaksi() {
        return Kode_transaksi;
    }

    public void setKode_transaksi(String Kode_transaksi) {
        this.Kode_transaksi = Kode_transaksi;
    }
    
    public String getKode_barang() {
        return Kode_barang;
    }

    public void setKode_barang(String Kode_barang) {
        this.Kode_barang = Kode_barang;
    }
    
    public String getQty() {
        return Qty;
    }

    public void setQty(String Qty) {
        this.Qty = Qty;
    }
    
    public String getKaryawan() {
        return Karyawan;
    }

    public void setKaryawan(String Karyawan) {
        this.Karyawan = Karyawan;
    }
    
    public String getPembeli() {
        return Pembeli;
    }

    public void setPembeli(String Pembeli) {
        this.Pembeli = Pembeli;
    }
    
    public String getWaktu() {
        return Waktu;
    }

    public void setWaktu(String Waktu) {
        this.Waktu = Waktu;
    }
    
    public Double getTotal() {
        return Total;
    }

    public void setTotal(Double Total) {
        this.Total = Total;
    }
    
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Riwayat other = (Riwayat) obj;
        if (!Objects.equals(this.Kode_transaksi, other.Kode_transaksi)) {
            return false;
        }
        if (!Objects.equals(this.Kode_barang, other.Kode_barang)) {
            return false;
        }
        if (!Objects.equals(this.Qty, other.Qty)) {
            return false;
        }
        if (!Objects.equals(this.Karyawan, other.Karyawan)) {
            return false;
        }
        if (!Objects.equals(this.Pembeli, other.Pembeli)) {
            return false;
        }
        if (!Objects.equals(this.Waktu, other.Waktu)) {
            return false;
        }
        if (!Objects.equals(this.Total, other.Total)) {
            return false;
        }
        return true;
    }
}
