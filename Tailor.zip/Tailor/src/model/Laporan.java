package model;

import java.util.Date;
import java.util.Objects;

public class Laporan {
    private Date Waktu;
    private String Transaksi;
    private Double Total;
    private Double GTotal;
    private String awal;
    private String akhir;
    
    public Laporan() {
        
    }
    
    public Date getWaktu() {
        return Waktu;
    }

    public void setWaktu(Date Waktu) {
        this.Waktu = Waktu;
    }
    
    public String getTransaksi() {
        return Transaksi;
    }

    public void setTransaksi(String Transaksi) {
        this.Transaksi = Transaksi;
    }
    
    public Double getTotal() {
        return Total;
    }

    public void setTotal(Double Total) {
        this.Total = Total;
    }
    
    public Double getGTotal() {
        return GTotal;
    }
    
    public void setGTotal(Double GTotal) {
        this.GTotal = GTotal;
    }
    
    public String getawal() {
        return awal;
    }
    
    public void setawal(String awal) {
        this.awal = awal;
    }
    
    public String getakhir() {
        return akhir;
    }
    
    public void setakhir(String akhir) {
        this.akhir = akhir;
    }
    
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Laporan other = (Laporan) obj;
        if (!Objects.equals(this.Waktu, other.Waktu)) {
            return false;
        }
        if (!Objects.equals(this.Transaksi, other.Transaksi)) {
            return false;
        }
        if (!Objects.equals(this.Total, other.Total)) {
            return false;
        }
        if (!Objects.equals(this.GTotal, other.GTotal)) {
            return false;
        }
        if (!Objects.equals(this.awal, other.awal)) {
            return false;
        }
        if (!Objects.equals(this.akhir, other.akhir)) {
            return false;
        }
        return true;
    }
}
