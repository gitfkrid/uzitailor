package model;

import java.util.Objects;

public class Laporan {
    private String Waktu;
    private String Transaksi;
    private String Total;
    
    public Laporan() {
        
    }
    
    public String getWaktu() {
        return Waktu;
    }

    public void setWaktu(String Waktu) {
        this.Waktu = Waktu;
    }
    
    public String getTransaksi() {
        return Transaksi;
    }

    public void setTransaksi(String Transaksi) {
        this.Transaksi = Transaksi;
    }
    
    public String getTotal() {
        return Total;
    }

    public void setTotal(String Total) {
        this.Total = Total;
    }
    
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Laporan other = (Laporan) obj;
        if (!Objects.equals(this.Waktu, other.Waktu)) {
            return false;
        }
        if (!Objects.equals(this.Transaksi, other.Transaksi)) {
            return false;
        }
        if (!Objects.equals(this.Total, other.Total)) {
            return false;
        }
        return true;
    }
}
