package model;

import java.util.Objects;

public class Pembeli {
   private String Id;
   private String Nama;
   private String Alamat;
   private String Hp;
   private int Pembelian;
   
   public Pembeli() {
       
   }
   
   public String getId() {
       return Id;
   }
   
   public void setId(String Id) {
       this.Id = Id;
   }
   
   public String getNama() {
       return Nama;
   }
   
   public void setNama(String Nama) {
       this.Nama = Nama;
   }
   
   public String getAlamat() {
       return Alamat;
   }
   
   public void setAlamat(String Alamat) {
       this.Alamat = Alamat;
   }
   
   public String getHp() {
       return Hp;
   }
   
   public void setHp(String Hp) {
       this.Hp = Hp;
   }
   
   public int getPembelian() {
       return Pembelian;
   }
   
   public void setPembelian(int Pembelian) {
       this.Pembelian = Pembelian;
   }
   
   public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pembeli other = (Pembeli) obj;
        if (!Objects.equals(this.Id, other.Id)) {
            return false;
        }
        if (!Objects.equals(this.Nama, other.Nama)) {
            return false;
        }
        if (!Objects.equals(this.Alamat, other.Alamat)) {
            return false;
        }
        if (!Objects.equals(this.Hp, other.Hp)) {
            return false;
        }
        if (!Objects.equals(this.Pembelian, other.Pembelian)) {
            return false;
        }
        return true;
    }
}
