package model;

import java.util.Date;

public class Transaksi{
    private String No_transaksi;
    private String Kode_barang;
    private String Nama_barang;
    private String Qty;
    private String Harga;
    private String Beli;
    private String Jadi;
    private String Karyawan;
    
    public Transaksi() {
        
    }
    
    public String getNo_transaksi() {
        return No_transaksi;
    }
    
    public void setNo_transaksi(String No_transaksi) {
        this.No_transaksi = No_transaksi;
    }
    
    public String getKode_barang() {
        return Kode_barang;
    }
    
    public void setKode_barang(String Kode_barang) {
        this.Kode_barang = Kode_barang;
    }
    
    public String getNama_barang() {
        return Nama_barang;
    }
    
    public void setNama_barang(String Nama_barang) {
        this.Nama_barang = Nama_barang;
    }
    
    public String getBeli() {
        return Beli;
    }
    
    public void setBeli(String Beli) {
        this.Beli = Beli;
    }
    
    public String getJadi() {
        return Jadi;
    }

    public void setJadi(String Jadi) {
        this.Jadi = Jadi;
    }
}
