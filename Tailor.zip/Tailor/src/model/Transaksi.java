package model;

public class Transaksi {
    
}
