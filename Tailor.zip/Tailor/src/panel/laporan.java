package panel;

import com.toedter.calendar.JDateChooser;
import db.Query;
import static java.awt.Component.CENTER_ALIGNMENT;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import model.Laporan;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableCellRenderer;
import views.TableColumnAdjuster;

public class laporan extends javax.swing.JPanel {
    
    private frame.main main;
    private Query query = new Query();
    private Laporan Laporan = new Laporan();
    private ArrayList<Laporan> list;
    DefaultTableModel tbl;
    
    private void alignCenter(int column) {
        
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);

        tb_laporan.getColumnModel().getColumn(column).setCellRenderer(renderer);
    }
    
    private void noTable() {
        int Baris = tbl.getRowCount();
        for (int a = 0; a < Baris; a++) {
            String nomor = String.valueOf(a + 1);
            tbl.setValueAt(nomor, a, 0);
        }
    }
    
    private void tbmodel() {
        JTableHeader header = tb_laporan.getTableHeader();
        header.setBackground(new java.awt.Color(217,4,41));
        header.setForeground(java.awt.Color.white);
        header.setFont(new Font("Poppins", Font.BOLD, 11));
        header.setAlignmentX(CENTER_ALIGNMENT);
    }

    public laporan(frame.main main) {
        initComponents();
        this.main = main;
        loadTable();
        tbmodel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barang = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        crud = new javax.swing.JPanel();
        export = new javax.swing.JButton();
        awal = new com.toedter.calendar.JDateChooser();
        akhir = new com.toedter.calendar.JDateChooser();
        total = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        field_total = new javax.swing.JLabel();
        content = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_laporan = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(874, 526));
        setLayout(new java.awt.BorderLayout());

        barang.setBackground(new java.awt.Color(255, 255, 255));
        barang.setPreferredSize(new java.awt.Dimension(550, 450));
        barang.setLayout(new java.awt.BorderLayout());

        header.setBackground(new java.awt.Color(255, 255, 255));
        header.setPreferredSize(new java.awt.Dimension(550, 50));
        header.setLayout(new java.awt.BorderLayout());

        crud.setBackground(new java.awt.Color(255, 255, 255));
        crud.setPreferredSize(new java.awt.Dimension(400, 50));
        crud.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 12, 15));

        export.setBackground(new java.awt.Color(255, 255, 255));
        export.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_export.png"))); // NOI18N
        export.setBorder(null);
        export.setPreferredSize(new java.awt.Dimension(30, 30));
        crud.add(export);

        awal.setDateFormatString("yyyy-MM-dd");
        awal.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        awal.setPreferredSize(new java.awt.Dimension(130, 30));
        awal.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                awalPropertyChange(evt);
            }
        });
        crud.add(awal);

        akhir.setDateFormatString("yyyy-MM-dd");
        akhir.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        akhir.setPreferredSize(new java.awt.Dimension(130, 30));
        akhir.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                akhirPropertyChange(evt);
            }
        });
        crud.add(akhir);

        header.add(crud, java.awt.BorderLayout.WEST);

        total.setBackground(new java.awt.Color(255, 255, 255));
        total.setPreferredSize(new java.awt.Dimension(400, 50));
        total.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 15, 30));

        jLabel1.setFont(new java.awt.Font("Poppins", 1, 12)); // NOI18N
        jLabel1.setText("Total Pendapatan : ");
        total.add(jLabel1);

        field_total.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        field_total.setText("Rp. 0.00");
        total.add(field_total);

        header.add(total, java.awt.BorderLayout.CENTER);

        barang.add(header, java.awt.BorderLayout.NORTH);

        content.setBackground(new java.awt.Color(255, 255, 255));
        content.setPreferredSize(new java.awt.Dimension(550, 400));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        tb_laporan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        tb_laporan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Username", "Nama Karyawan", "Alamat Karyawan", "Jenis Kelamin", "No HP", "Jabatan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tb_laporan.setRowHeight(20);
        tb_laporan.setSelectionBackground(new java.awt.Color(239, 35, 60));
        jScrollPane1.setViewportView(tb_laporan);

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 854, Short.MAX_VALUE)
                .addContainerGap())
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                .addContainerGap())
        );

        barang.add(content, java.awt.BorderLayout.CENTER);

        add(barang, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void awalPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_awalPropertyChange
        if(awal.getDate()!=null){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Laporan.setawal(sdf.format(awal.getDate()));
            Laporan.setakhir(sdf.format(akhir.getDate()));
        }
    }//GEN-LAST:event_awalPropertyChange

    private void akhirPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_akhirPropertyChange
        if(akhir.getDate()!=null){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Laporan.setawal(sdf.format(awal.getDate()));
            Laporan.setakhir(sdf.format(akhir.getDate()));
            filterTable();
        }
    }//GEN-LAST:event_akhirPropertyChange

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser akhir;
    private com.toedter.calendar.JDateChooser awal;
    private javax.swing.JPanel barang;
    private javax.swing.JPanel content;
    private javax.swing.JPanel crud;
    private javax.swing.JButton export;
    private javax.swing.JLabel field_total;
    private javax.swing.JPanel header;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tb_laporan;
    private javax.swing.JPanel total;
    // End of variables declaration//GEN-END:variables
    
    private void loadTable() {
        list = Query.getLaporan();
        String[] heading = {"No","Waktu", "No Transaksi", "Total"};
        tbl = new DefaultTableModel (null,heading);
        tb_laporan.setModel(tbl);
        tbl = (DefaultTableModel) tb_laporan.getModel();
        tbl.setRowCount(0);
        for(Laporan l:list){
            tbl.addRow(new Object[]{"", l.getWaktu(), l.getTransaksi(), String.format("%,.2f", l.getTotal())});
        }
        noTable();
        for (int i = 0; i < 4; i++) {
            alignCenter(i);
        }
    }
    
    private void filterTable() { 
        list = Query.setLaporan(Laporan.getawal(), Laporan.getakhir());
        String[] heading = {"No","Tanggal Transaksi", "No Transaksi", "Total"};
        tbl = new DefaultTableModel (null,heading);
        tb_laporan.setModel(tbl);
        tbl = (DefaultTableModel) tb_laporan.getModel();
        tbl.setRowCount(0);
        for(Laporan l:list){
            tbl.addRow(new Object[]{"", l.getWaktu(), l.getTransaksi(), "Rp. " + String.format("%,.2f", l.getTotal())});
            field_total.setText("Rp. " + String.format("%,.2f", l.getGTotal()));
        }
        noTable();
        for (int i = 0; i < 4; i++) {
            alignCenter(i);
        }
    }
}
