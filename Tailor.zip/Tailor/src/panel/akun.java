package panel;

import db.Query;
import static java.awt.Component.CENTER_ALIGNMENT;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import model.account;
import dialog.akun_tambah;

public class akun extends javax.swing.JPanel {
    
    private frame.main main;
    private Query query = new Query();
    private account Akun = new account();
    private ArrayList<account> list;
    DefaultTableModel tbl;
    
    private void tbmodel() {
        JTableHeader header = tb_akun.getTableHeader();
        header.setBackground(new java.awt.Color(217,4,41));
        header.setForeground(java.awt.Color.white);
        header.setFont(new Font("Poppins", Font.BOLD, 11));
        header.setAlignmentX(CENTER_ALIGNMENT);
    }

    public akun(frame.main main) {
        initComponents();
        this.main = main;
        loadTable();
        tbmodel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barang = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        crud = new javax.swing.JPanel();
        add = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        search = new javax.swing.JPanel();
        search_panel = new javax.swing.JPanel();
        txt_search = new javax.swing.JTextField();
        search_bar = new javax.swing.JLabel();
        content = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_akun = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(550, 450));
        setLayout(new java.awt.BorderLayout());

        barang.setBackground(new java.awt.Color(255, 255, 255));
        barang.setPreferredSize(new java.awt.Dimension(550, 450));
        barang.setLayout(new java.awt.BorderLayout());

        header.setPreferredSize(new java.awt.Dimension(550, 50));
        header.setLayout(new java.awt.BorderLayout());

        crud.setBackground(new java.awt.Color(255, 255, 255));
        crud.setPreferredSize(new java.awt.Dimension(200, 50));
        crud.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 12, 15));

        add.setBackground(new java.awt.Color(255, 255, 255));
        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_add.png"))); // NOI18N
        add.setBorder(null);
        add.setPreferredSize(new java.awt.Dimension(30, 30));
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        crud.add(add);

        delete.setBackground(new java.awt.Color(255, 255, 255));
        delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_delete.png"))); // NOI18N
        delete.setBorder(null);
        delete.setPreferredSize(new java.awt.Dimension(30, 30));
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        crud.add(delete);

        header.add(crud, java.awt.BorderLayout.WEST);

        search.setBackground(new java.awt.Color(255, 255, 255));
        search.setPreferredSize(new java.awt.Dimension(400, 50));
        search.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 15));

        search_panel.setBackground(new java.awt.Color(255, 255, 255));
        search_panel.setPreferredSize(new java.awt.Dimension(200, 50));
        search_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_search.setBackground(new java.awt.Color(237, 242, 244));
        txt_search.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txt_search.setBorder(null);
        txt_search.setPreferredSize(new java.awt.Dimension(130, 20));
        txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_searchKeyReleased(evt);
            }
        });
        search_panel.add(txt_search, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 5, -1, -1));

        search_bar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/search.png"))); // NOI18N
        search_panel.add(search_bar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        search.add(search_panel);

        header.add(search, java.awt.BorderLayout.CENTER);

        barang.add(header, java.awt.BorderLayout.NORTH);

        content.setBackground(new java.awt.Color(255, 255, 255));
        content.setPreferredSize(new java.awt.Dimension(550, 400));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        tb_akun.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Username", "Nama Karyawan", "Alamat Karyawan", "Jenis Kelamin", "No HP", "Jabatan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tb_akun);

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 530, Short.MAX_VALUE)
                .addContainerGap())
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 378, Short.MAX_VALUE)
                .addContainerGap())
        );

        barang.add(content, java.awt.BorderLayout.CENTER);

        add(barang, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        akun_tambah ak = new akun_tambah(null, true);
        ak.setVisible(true);
        loadTable();
    }//GEN-LAST:event_addActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        if(tb_akun.getSelectedRow()<0){
            JOptionPane.showMessageDialog(null, "NO SELECTED ITEM","EMPTY SELECTION" ,JOptionPane.ERROR_MESSAGE);
            return;
        }
        int Pilih = JOptionPane.showConfirmDialog(null,"Apakah yakin data ingin dihapus ?","Peringatan",JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (Pilih == JOptionPane.OK_OPTION) {
            int row = tb_akun.getSelectedRow();
            if (row != -1) {
                Object Username = tb_akun.getValueAt(row, 0);
                Akun.setUsername(Username.toString());
                new Query().deleteAkun(Akun.getUsername());
                loadTable();
            }    
        }
    }//GEN-LAST:event_deleteActionPerformed

    private void txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_searchKeyReleased
        String text = txt_search.getText().trim();
        filterTable(text);
    }//GEN-LAST:event_txt_searchKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JPanel barang;
    private javax.swing.JPanel content;
    private javax.swing.JPanel crud;
    private javax.swing.JButton delete;
    private javax.swing.JPanel header;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel search;
    private javax.swing.JLabel search_bar;
    private javax.swing.JPanel search_panel;
    private javax.swing.JTable tb_akun;
    private javax.swing.JTextField txt_search;
    // End of variables declaration//GEN-END:variables
    
    private void loadTable() {
        list = Query.getAkun();
        String[] heading = {"Username","Nama Karyawan", "Alamat Karyawan", "Jenis Kelamin", "No HP", "Jabatan"};
        tbl = new DefaultTableModel (null,heading);
        tb_akun.setModel(tbl);
        tbl = (DefaultTableModel) tb_akun.getModel();
        tbl.setRowCount(0);
        for(account l:list){
            tbl.addRow(new Object[]{l.getUsername(),l.getNama(),l.getAlamat(),l.getKelamin(),l.getHp(),l.getJabatan()});
        }
    }
    
    private void filterTable(String text) { 
        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(((DefaultTableModel) tb_akun.getModel()));
        if (text.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter(text));
        };
        tb_akun.setRowSorter(sorter);
    }
}
