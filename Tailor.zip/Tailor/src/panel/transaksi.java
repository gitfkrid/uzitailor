package panel;

import static java.awt.Component.CENTER_ALIGNMENT;
import java.awt.Font;
import javax.swing.table.JTableHeader;

public class transaksi extends javax.swing.JPanel {
    
    private frame.main main;
    
     private void tbmodel() {
        JTableHeader header = tb_transaksi.getTableHeader();
        header.setBackground(new java.awt.Color(217,4,41));
        header.setForeground(java.awt.Color.white);
        header.setFont(new Font("Poppins", Font.BOLD, 11));
        header.setAlignmentX(CENTER_ALIGNMENT);
    }

    public transaksi(frame.main main) {
        initComponents();
        this.main = main;
        tbmodel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barang = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        crud = new javax.swing.JPanel();
        id = new javax.swing.JLabel();
        id_pembeli = new javax.swing.JTextField();
        nama = new javax.swing.JLabel();
        nama_pembeli = new javax.swing.JTextField();
        alamat = new javax.swing.JLabel();
        alamat_pembeli = new javax.swing.JTextField();
        hp = new javax.swing.JLabel();
        no_hp = new javax.swing.JTextField();
        search = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        content = new javax.swing.JPanel();
        form_barang = new javax.swing.JPanel();
        kode = new javax.swing.JPanel();
        txtkodetrx = new javax.swing.JLabel();
        kode_transaksi = new javax.swing.JTextField();
        brg = new javax.swing.JPanel();
        txtkodebrg = new javax.swing.JLabel();
        kode_barang = new javax.swing.JTextField();
        qt = new javax.swing.JPanel();
        txtqty = new javax.swing.JLabel();
        qty = new javax.swing.JTextField();
        sub = new javax.swing.JPanel();
        txtharga = new javax.swing.JLabel();
        harga = new javax.swing.JTextField();
        beli = new javax.swing.JPanel();
        txtbeli = new javax.swing.JLabel();
        tanggal_beli = new com.toedter.calendar.JDateChooser();
        jadi = new javax.swing.JPanel();
        txtjadi = new javax.swing.JLabel();
        tanggal_jadi = new com.toedter.calendar.JDateChooser();
        kary = new javax.swing.JPanel();
        txtkaryawan = new javax.swing.JLabel();
        karyawan = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_transaksi = new javax.swing.JTable();
        form_bayar = new javax.swing.JPanel();
        fdibayar = new javax.swing.JPanel();
        txtkodetrx1 = new javax.swing.JLabel();
        kode_transaksi1 = new javax.swing.JTextField();
        fsisabayar = new javax.swing.JPanel();
        txtkodetrx2 = new javax.swing.JLabel();
        kode_transaksi2 = new javax.swing.JTextField();
        fdibayar2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(874, 526));
        setLayout(new java.awt.BorderLayout(10, 10));

        barang.setBackground(new java.awt.Color(255, 255, 255));
        barang.setPreferredSize(new java.awt.Dimension(550, 450));
        barang.setLayout(new java.awt.BorderLayout(10, 10));

        header.setPreferredSize(new java.awt.Dimension(550, 110));
        header.setLayout(new java.awt.BorderLayout(0, 10));

        crud.setBackground(new java.awt.Color(255, 255, 255));
        crud.setPreferredSize(new java.awt.Dimension(480, 100));
        crud.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        id.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        id.setText("Id Pembeli");
        crud.add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        id_pembeli.setBackground(new java.awt.Color(237, 242, 244));
        id_pembeli.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        id_pembeli.setToolTipText("");
        id_pembeli.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        id_pembeli.setPreferredSize(new java.awt.Dimension(200, 30));
        crud.add(id_pembeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        nama.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        nama.setText("Nama Pembeli");
        crud.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, -1, -1));

        nama_pembeli.setBackground(new java.awt.Color(237, 242, 244));
        nama_pembeli.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        nama_pembeli.setToolTipText("");
        nama_pembeli.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        nama_pembeli.setPreferredSize(new java.awt.Dimension(240, 30));
        crud.add(nama_pembeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, -1, -1));

        alamat.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        alamat.setText("Alamat Pembeli");
        crud.add(alamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        alamat_pembeli.setBackground(new java.awt.Color(237, 242, 244));
        alamat_pembeli.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        alamat_pembeli.setToolTipText("");
        alamat_pembeli.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        alamat_pembeli.setPreferredSize(new java.awt.Dimension(200, 30));
        crud.add(alamat_pembeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        hp.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        hp.setText("No Hp");
        crud.add(hp, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 60, -1, -1));

        no_hp.setBackground(new java.awt.Color(237, 242, 244));
        no_hp.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        no_hp.setToolTipText("");
        no_hp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        no_hp.setPreferredSize(new java.awt.Dimension(240, 30));
        crud.add(no_hp, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, -1, -1));

        header.add(crud, java.awt.BorderLayout.WEST);

        search.setBackground(new java.awt.Color(43, 45, 66));
        search.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 0, 0, 0, new java.awt.Color(217, 4, 41)));
        search.setPreferredSize(new java.awt.Dimension(220, 50));
        search.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 20));

        jLabel1.setFont(new java.awt.Font("Poppins SemiBold", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 255, 0));
        jLabel1.setText("Rp. 1,000,000.00");
        search.add(jLabel1);

        header.add(search, java.awt.BorderLayout.CENTER);

        barang.add(header, java.awt.BorderLayout.NORTH);

        content.setBackground(new java.awt.Color(255, 255, 255));
        content.setPreferredSize(new java.awt.Dimension(550, 110));

        form_barang.setBackground(new java.awt.Color(255, 255, 255));
        form_barang.setPreferredSize(new java.awt.Dimension(874, 70));
        form_barang.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 10));

        kode.setBackground(new java.awt.Color(255, 255, 255));
        kode.setMinimumSize(new java.awt.Dimension(100, 50));
        kode.setPreferredSize(new java.awt.Dimension(100, 50));
        kode.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkodetrx.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtkodetrx.setText("Kode Transaksi");
        kode.add(txtkodetrx, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        kode_transaksi.setBackground(new java.awt.Color(237, 242, 244));
        kode_transaksi.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode_transaksi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        kode_transaksi.setText("24042200001");
        kode_transaksi.setToolTipText("");
        kode_transaksi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode_transaksi.setEnabled(false);
        kode_transaksi.setPreferredSize(new java.awt.Dimension(100, 30));
        kode.add(kode_transaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, -1, -1));

        form_barang.add(kode);

        brg.setBackground(new java.awt.Color(255, 255, 255));
        brg.setPreferredSize(new java.awt.Dimension(100, 50));
        brg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkodebrg.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtkodebrg.setText("Kode Barang");
        brg.add(txtkodebrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        kode_barang.setBackground(new java.awt.Color(237, 242, 244));
        kode_barang.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        kode_barang.setToolTipText("");
        kode_barang.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        kode_barang.setPreferredSize(new java.awt.Dimension(100, 30));
        brg.add(kode_barang, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, -1, -1));

        form_barang.add(brg);

        qt.setBackground(new java.awt.Color(255, 255, 255));
        qt.setPreferredSize(new java.awt.Dimension(50, 50));
        qt.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtqty.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtqty.setText("Qty");
        qt.add(txtqty, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        qty.setBackground(new java.awt.Color(237, 242, 244));
        qty.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        qty.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        qty.setToolTipText("");
        qty.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        qty.setPreferredSize(new java.awt.Dimension(100, 30));
        qt.add(qty, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 50, -1));

        form_barang.add(qt);

        sub.setBackground(new java.awt.Color(255, 255, 255));
        sub.setPreferredSize(new java.awt.Dimension(100, 50));
        sub.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtharga.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtharga.setText("Harga");
        sub.add(txtharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        harga.setBackground(new java.awt.Color(237, 242, 244));
        harga.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        harga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        harga.setToolTipText("");
        harga.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        harga.setPreferredSize(new java.awt.Dimension(100, 30));
        sub.add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, -1, -1));

        form_barang.add(sub);

        beli.setBackground(new java.awt.Color(255, 255, 255));
        beli.setPreferredSize(new java.awt.Dimension(170, 50));
        beli.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtbeli.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtbeli.setText("Tanggal Pembelian");
        beli.add(txtbeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        tanggal_beli.setDateFormatString("yyyy-MM-dd");
        tanggal_beli.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        tanggal_beli.setPreferredSize(new java.awt.Dimension(130, 30));
        tanggal_beli.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tanggal_beliPropertyChange(evt);
            }
        });
        beli.add(tanggal_beli, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 170, -1));

        form_barang.add(beli);

        jadi.setBackground(new java.awt.Color(255, 255, 255));
        jadi.setPreferredSize(new java.awt.Dimension(170, 50));
        jadi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtjadi.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtjadi.setText("Tanggal Jadi");
        jadi.add(txtjadi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        tanggal_jadi.setDateFormatString("yyyy-MM-dd");
        tanggal_jadi.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        tanggal_jadi.setPreferredSize(new java.awt.Dimension(130, 30));
        tanggal_jadi.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tanggal_jadiPropertyChange(evt);
            }
        });
        jadi.add(tanggal_jadi, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 170, -1));

        form_barang.add(jadi);

        kary.setBackground(new java.awt.Color(255, 255, 255));
        kary.setPreferredSize(new java.awt.Dimension(100, 50));
        kary.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkaryawan.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtkaryawan.setText("Karyawan");
        kary.add(txtkaryawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        karyawan.setBackground(new java.awt.Color(237, 242, 244));
        karyawan.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        karyawan.setText("thoriq");
        karyawan.setToolTipText("");
        karyawan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(141, 153, 174)));
        karyawan.setEnabled(false);
        karyawan.setPreferredSize(new java.awt.Dimension(100, 30));
        kary.add(karyawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, -1, -1));

        form_barang.add(kary);

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(850, 216));

        tb_transaksi.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        tb_transaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode Transaksi", "Kode Barang", "QTY", "Sub Total", "Tanggal Pembelian", "Tanggal Jadi", "Karyawan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tb_transaksi.setRowHeight(20);
        tb_transaksi.setSelectionBackground(new java.awt.Color(239, 35, 60));
        jScrollPane1.setViewportView(tb_transaksi);

        form_bayar.setBackground(new java.awt.Color(255, 255, 255));
        form_bayar.setPreferredSize(new java.awt.Dimension(874, 110));
        form_bayar.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 10));

        fdibayar.setBackground(new java.awt.Color(255, 255, 255));
        fdibayar.setPreferredSize(new java.awt.Dimension(250, 90));
        fdibayar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkodetrx1.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtkodetrx1.setText("Dibayar");
        fdibayar.add(txtkodetrx1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        kode_transaksi1.setBackground(new java.awt.Color(43, 45, 66));
        kode_transaksi1.setFont(new java.awt.Font("Poppins SemiBold", 0, 24)); // NOI18N
        kode_transaksi1.setForeground(new java.awt.Color(102, 255, 0));
        kode_transaksi1.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        kode_transaksi1.setText("Rp. 50,000.00");
        kode_transaksi1.setToolTipText("");
        kode_transaksi1.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 0, 0, 0, new java.awt.Color(217, 4, 41)));
        kode_transaksi1.setPreferredSize(new java.awt.Dimension(100, 30));
        fdibayar.add(kode_transaksi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 250, 70));

        form_bayar.add(fdibayar);

        fsisabayar.setBackground(new java.awt.Color(255, 255, 255));
        fsisabayar.setPreferredSize(new java.awt.Dimension(250, 90));
        fsisabayar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkodetrx2.setFont(new java.awt.Font("Poppins", 0, 10)); // NOI18N
        txtkodetrx2.setText("Sisa Pembayaran");
        fsisabayar.add(txtkodetrx2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        kode_transaksi2.setBackground(new java.awt.Color(43, 45, 66));
        kode_transaksi2.setFont(new java.awt.Font("Poppins SemiBold", 0, 24)); // NOI18N
        kode_transaksi2.setForeground(new java.awt.Color(102, 255, 0));
        kode_transaksi2.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        kode_transaksi2.setText("Rp. 10.000.00");
        kode_transaksi2.setToolTipText("");
        kode_transaksi2.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 0, 0, 0, new java.awt.Color(217, 4, 41)));
        kode_transaksi2.setPreferredSize(new java.awt.Dimension(100, 30));
        fsisabayar.add(kode_transaksi2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 250, 70));

        form_bayar.add(fsisabayar);

        fdibayar2.setBackground(new java.awt.Color(255, 255, 255));
        fdibayar2.setPreferredSize(new java.awt.Dimension(330, 90));
        fdibayar2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 40));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Save.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setPreferredSize(new java.awt.Dimension(90, 30));
        fdibayar2.add(jButton1);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_print.png"))); // NOI18N
        jButton2.setBorder(null);
        jButton2.setPreferredSize(new java.awt.Dimension(90, 30));
        fdibayar2.add(jButton2);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Clear.png"))); // NOI18N
        jButton3.setBorder(null);
        jButton3.setPreferredSize(new java.awt.Dimension(90, 30));
        fdibayar2.add(jButton3);

        form_bayar.add(fdibayar2);

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(form_barang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(14, 14, 14))
            .addComponent(form_bayar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentLayout.createSequentialGroup()
                .addComponent(form_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(form_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        barang.add(content, java.awt.BorderLayout.CENTER);

        add(barang, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void tanggal_beliPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tanggal_beliPropertyChange
        
    }//GEN-LAST:event_tanggal_beliPropertyChange

    private void tanggal_jadiPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tanggal_jadiPropertyChange
        
    }//GEN-LAST:event_tanggal_jadiPropertyChange

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel alamat;
    private javax.swing.JTextField alamat_pembeli;
    private javax.swing.JPanel barang;
    private javax.swing.JPanel beli;
    private javax.swing.JPanel brg;
    private javax.swing.JPanel content;
    private javax.swing.JPanel crud;
    private javax.swing.JPanel fdibayar;
    private javax.swing.JPanel fdibayar2;
    private javax.swing.JPanel form_barang;
    private javax.swing.JPanel form_bayar;
    private javax.swing.JPanel fsisabayar;
    private javax.swing.JTextField harga;
    private javax.swing.JPanel header;
    private javax.swing.JLabel hp;
    private javax.swing.JLabel id;
    private javax.swing.JTextField id_pembeli;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel jadi;
    private javax.swing.JPanel kary;
    private javax.swing.JTextField karyawan;
    private javax.swing.JPanel kode;
    private javax.swing.JTextField kode_barang;
    private javax.swing.JTextField kode_transaksi;
    private javax.swing.JTextField kode_transaksi1;
    private javax.swing.JTextField kode_transaksi2;
    private javax.swing.JLabel nama;
    private javax.swing.JTextField nama_pembeli;
    private javax.swing.JTextField no_hp;
    private javax.swing.JPanel qt;
    private javax.swing.JTextField qty;
    private javax.swing.JPanel search;
    private javax.swing.JPanel sub;
    private com.toedter.calendar.JDateChooser tanggal_beli;
    private com.toedter.calendar.JDateChooser tanggal_jadi;
    private javax.swing.JTable tb_transaksi;
    private javax.swing.JLabel txtbeli;
    private javax.swing.JLabel txtharga;
    private javax.swing.JLabel txtjadi;
    private javax.swing.JLabel txtkaryawan;
    private javax.swing.JLabel txtkodebrg;
    private javax.swing.JLabel txtkodetrx;
    private javax.swing.JLabel txtkodetrx1;
    private javax.swing.JLabel txtkodetrx2;
    private javax.swing.JLabel txtqty;
    // End of variables declaration//GEN-END:variables
    
}
