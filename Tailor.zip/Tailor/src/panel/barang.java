package panel;

import db.Query;
import dialog.barang_edit;
import dialog.barang_tambah;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import model.masterBarang;
import views.TableColumnAdjuster;

public class barang extends javax.swing.JPanel {
    
    private frame.main main;
    private Query query = new Query();
    private masterBarang Barang = new masterBarang();
    private ArrayList<masterBarang> list;
    DefaultTableModel tbl;
    
    private void alignCenter(int column) {
        
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);

        tb_barang.getColumnModel().getColumn(column).setCellRenderer(renderer);
    }
    
    private void noTable() {
        int Baris = tbl.getRowCount();
        for (int a = 0; a < Baris; a++) {
            String nomor = String.valueOf(a + 1);
            tbl.setValueAt(nomor, a, 0);
        }
    }
    
    private void tbmodel() {
        JTableHeader header = tb_barang.getTableHeader();
        header.setBackground(new java.awt.Color(217,4,41));
        header.setForeground(java.awt.Color.white);
        header.setFont(new Font("Poppins", Font.BOLD, 11));
        header.setAlignmentX(CENTER_ALIGNMENT);
    }

    public barang(frame.main main) {
        initComponents();
        this.main = main;
        loadTable();
        tbmodel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barang = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        crud = new javax.swing.JPanel();
        add = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        search = new javax.swing.JPanel();
        search_panel = new javax.swing.JPanel();
        txt_search = new javax.swing.JTextField();
        search_bar = new javax.swing.JLabel();
        content = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tb_barang = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(550, 450));
        setLayout(new java.awt.BorderLayout());

        barang.setBackground(new java.awt.Color(255, 255, 255));
        barang.setPreferredSize(new java.awt.Dimension(550, 450));
        barang.setLayout(new java.awt.BorderLayout());

        header.setPreferredSize(new java.awt.Dimension(550, 50));
        header.setLayout(new java.awt.BorderLayout());

        crud.setBackground(new java.awt.Color(255, 255, 255));
        crud.setPreferredSize(new java.awt.Dimension(200, 50));
        crud.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 12, 15));

        add.setBackground(new java.awt.Color(255, 255, 255));
        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_add.png"))); // NOI18N
        add.setBorder(null);
        add.setPreferredSize(new java.awt.Dimension(30, 30));
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        crud.add(add);

        edit.setBackground(new java.awt.Color(255, 255, 255));
        edit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_edit.png"))); // NOI18N
        edit.setBorder(null);
        edit.setPreferredSize(new java.awt.Dimension(30, 30));
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        crud.add(edit);

        delete.setBackground(new java.awt.Color(255, 255, 255));
        delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btn_delete.png"))); // NOI18N
        delete.setBorder(null);
        delete.setPreferredSize(new java.awt.Dimension(30, 30));
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        crud.add(delete);

        header.add(crud, java.awt.BorderLayout.WEST);

        search.setBackground(new java.awt.Color(255, 255, 255));
        search.setPreferredSize(new java.awt.Dimension(400, 50));
        search.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 15));

        search_panel.setBackground(new java.awt.Color(255, 255, 255));
        search_panel.setPreferredSize(new java.awt.Dimension(200, 50));
        search_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_search.setBackground(new java.awt.Color(237, 242, 244));
        txt_search.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txt_search.setBorder(null);
        txt_search.setPreferredSize(new java.awt.Dimension(130, 20));
        txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_searchKeyReleased(evt);
            }
        });
        search_panel.add(txt_search, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 5, -1, -1));

        search_bar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/search.png"))); // NOI18N
        search_panel.add(search_bar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        search.add(search_panel);

        header.add(search, java.awt.BorderLayout.CENTER);

        barang.add(header, java.awt.BorderLayout.NORTH);

        content.setBackground(new java.awt.Color(255, 255, 255));
        content.setPreferredSize(new java.awt.Dimension(550, 400));

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setAutoscrolls(true);
        jScrollPane2.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        jScrollPane2.setPreferredSize(new java.awt.Dimension(530, 379));

        tb_barang.setFont(new java.awt.Font("Poppins", 0, 11)); // NOI18N
        tb_barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id Karyawan", "Nama Karyawan", "Alamat Karyawan", "Jenis Kelamin", "No Hp", "Jabatan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tb_barang.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tb_barang.setGridColor(new java.awt.Color(43, 45, 66));
        tb_barang.setPreferredSize(new java.awt.Dimension(2020, 500));
        tb_barang.setRowHeight(20);
        tb_barang.setSelectionBackground(new java.awt.Color(239, 35, 60));
        jScrollPane2.setViewportView(tb_barang);

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 378, Short.MAX_VALUE)
                .addContainerGap())
        );

        barang.add(content, java.awt.BorderLayout.CENTER);

        add(barang, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        barang_tambah ak = new barang_tambah(null, true);
        ak.setVisible(true);
        loadTable();
    }//GEN-LAST:event_addActionPerformed

    private void txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_searchKeyReleased
        String text = txt_search.getText().trim();
        filterTable(text);
    }//GEN-LAST:event_txt_searchKeyReleased

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        if(tb_barang.getSelectedRow()<0){
            JOptionPane.showMessageDialog(null, "NO SELECTED ITEM","EMPTY SELECTION" ,JOptionPane.ERROR_MESSAGE);
            return;
        }
        barang_edit bt = new barang_edit(null, true);
        bt.setBarang(list.get(tb_barang.getSelectedRow()));
        bt.setVisible(true);
        loadTable();
    }//GEN-LAST:event_editActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        if(tb_barang.getSelectedRow()<0){
            JOptionPane.showMessageDialog(null, "NO SELECTED ITEM","EMPTY SELECTION" ,JOptionPane.ERROR_MESSAGE);
            return;
        }
        int Pilih = JOptionPane.showConfirmDialog(null,"Apakah yakin data ingin dihapus ?","Peringatan",JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
        if (Pilih == JOptionPane.OK_OPTION) {
            int row = tb_barang.getSelectedRow();
            if (row != -1) {
                Object Kode = tb_barang.getValueAt(row, 2);
                Barang.setKode(Kode.toString());
                new Query().deleteBarang(Barang.getKode());
                loadTable();
            }
        }
    }//GEN-LAST:event_deleteActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JPanel barang;
    private javax.swing.JPanel content;
    private javax.swing.JPanel crud;
    private javax.swing.JButton delete;
    private javax.swing.JButton edit;
    private javax.swing.JPanel header;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel search;
    private javax.swing.JLabel search_bar;
    private javax.swing.JPanel search_panel;
    private javax.swing.JTable tb_barang;
    private javax.swing.JTextField txt_search;
    // End of variables declaration//GEN-END:variables
    
    private void loadTable() {
        list = Query.getBarang();
        String[] heading = {"No","Nama Barang", "Kode Barang", "Lebar Dada", "Panjang Pakaian", "Lebar Panggul", "Lingkar Panggul", "Lingkar Pinggang", "Panjang Tangan", "Panjang Celana", "Lingkar Dada", "Lingkar Perut", "Lebar Pinggul", "Lingkar Punggung", "Lingkar Lengan", "Set Lingkar Badan", "Lebar Pundak", "Lebar Badan", "Set Lingkar Lengan", "Panjang Lengan", "Tinggi Leher", "Lebar Bawah"};
        tbl = new DefaultTableModel (null,heading);
        tb_barang.setModel(tbl);
        tbl = (DefaultTableModel) tb_barang.getModel();
        tbl.setRowCount(0);
        for(masterBarang l:list){
            tbl.addRow(new Object[]{"",l.getNama(), l.getKode(), l.getLebar_dada(),l.getPanjang_pakaian(), l.getLebar_panggul(), l.getLingkar_panggul(),l.getLingkar_pinggang(), l.getPanjang_tangan(), l.getPanjang_celana(), l.getLingkar_dada(), l.getLingkar_perut(), l.getLebar_pinggul(),l.getLingkar_punggung(), l.getLingkar_lengan(), l.getSet_lingkar_badan(),l.getLebar_pundak(), l.getLebar_badan(), l.getSet_lingkar_lengan(),l.getPanjang_lengan(), l.getTinggi_leher(), l.getLebar_bawah()});
        }
        noTable();
        alignCenter(0);
        for (int i = 3; i < 22; i++) {
            alignCenter(i);
        }
        TableColumnAdjuster fit = new TableColumnAdjuster(tb_barang); 
        fit.adjustColumns();
    }
    
    private void filterTable(String text) { 
        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(((DefaultTableModel) tb_barang.getModel()));
        if (text.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter(text));
        };
        tb_barang.setRowSorter(sorter);
    }
}
