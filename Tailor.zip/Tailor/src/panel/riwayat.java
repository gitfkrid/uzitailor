package panel;

import db.Query;
import static java.awt.Component.CENTER_ALIGNMENT;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import model.Riwayat;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableCellRenderer;
import views.TableColumnAdjuster;

public class riwayat extends javax.swing.JPanel {
    
    private frame.main main;
    private Query query = new Query();
    private Riwayat Riwayat = new Riwayat();
    private ArrayList<Riwayat> list;
    DefaultTableModel tbl;
    
    private void alignCenter(int column) {
        
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);

        tb_riwayat.getColumnModel().getColumn(column).setCellRenderer(renderer);
    }
    
    private void noTable() {
        int Baris = tbl.getRowCount();
        for (int a = 0; a < Baris; a++) {
            String nomor = String.valueOf(a + 1);
            tbl.setValueAt(nomor, a, 0);
        }
    }
    
    private void tbmodel() {
        JTableHeader header = tb_riwayat.getTableHeader();
        header.setBackground(new java.awt.Color(217,4,41));
        header.setForeground(java.awt.Color.white);
        header.setFont(new Font("Poppins", Font.BOLD, 11));
        header.setAlignmentX(CENTER_ALIGNMENT);
    }

    public riwayat(frame.main main) {
        initComponents();
        this.main = main;
        loadTable();
        tbmodel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barang = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        crud = new javax.swing.JPanel();
        search = new javax.swing.JPanel();
        search_panel = new javax.swing.JPanel();
        txt_search = new javax.swing.JTextField();
        search_bar = new javax.swing.JLabel();
        content = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_riwayat = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(550, 450));
        setLayout(new java.awt.BorderLayout());

        barang.setBackground(new java.awt.Color(255, 255, 255));
        barang.setPreferredSize(new java.awt.Dimension(550, 450));
        barang.setLayout(new java.awt.BorderLayout());

        header.setPreferredSize(new java.awt.Dimension(550, 50));
        header.setLayout(new java.awt.BorderLayout());

        crud.setBackground(new java.awt.Color(255, 255, 255));
        crud.setPreferredSize(new java.awt.Dimension(200, 50));
        crud.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 15));
        header.add(crud, java.awt.BorderLayout.WEST);

        search.setBackground(new java.awt.Color(255, 255, 255));
        search.setPreferredSize(new java.awt.Dimension(400, 50));
        search.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 15));

        search_panel.setBackground(new java.awt.Color(255, 255, 255));
        search_panel.setPreferredSize(new java.awt.Dimension(200, 50));
        search_panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_search.setBackground(new java.awt.Color(237, 242, 244));
        txt_search.setFont(new java.awt.Font("Poppins", 0, 12)); // NOI18N
        txt_search.setBorder(null);
        txt_search.setPreferredSize(new java.awt.Dimension(130, 20));
        txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_searchKeyReleased(evt);
            }
        });
        search_panel.add(txt_search, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 5, -1, -1));

        search_bar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/search.png"))); // NOI18N
        search_panel.add(search_bar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        search.add(search_panel);

        header.add(search, java.awt.BorderLayout.CENTER);

        barang.add(header, java.awt.BorderLayout.NORTH);

        content.setBackground(new java.awt.Color(255, 255, 255));
        content.setPreferredSize(new java.awt.Dimension(550, 400));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        tb_riwayat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Username", "Nama Karyawan", "Alamat Karyawan", "Jenis Kelamin", "No HP", "Jabatan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tb_riwayat);

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 530, Short.MAX_VALUE)
                .addContainerGap())
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 378, Short.MAX_VALUE)
                .addContainerGap())
        );

        barang.add(content, java.awt.BorderLayout.CENTER);

        add(barang, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_searchKeyReleased
        String text = txt_search.getText().trim();
        filterTable(text);
    }//GEN-LAST:event_txt_searchKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel barang;
    private javax.swing.JPanel content;
    private javax.swing.JPanel crud;
    private javax.swing.JPanel header;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel search;
    private javax.swing.JLabel search_bar;
    private javax.swing.JPanel search_panel;
    private javax.swing.JTable tb_riwayat;
    private javax.swing.JTextField txt_search;
    // End of variables declaration//GEN-END:variables
    
    private void loadTable() {
        list = Query.getRiwayat();
        String[] heading = {"No","No Transaksi", "Nama Barang", "QTY", "Karyawan", "Pembeli", "Waktu", "Total"};
        tbl = new DefaultTableModel (null,heading);
        tb_riwayat.setModel(tbl);
        tbl = (DefaultTableModel) tb_riwayat.getModel();
        tbl.setRowCount(0);
        for(Riwayat l:list){
            tbl.addRow(new Object[]{"", l.getKode_transaksi(), l.getKode_barang(), l.getQty(), l.getKaryawan(), l.getPembeli(), l.getWaktu(), l.getTotal()});
        }
        noTable();
        for (int i = 0; i < 8; i++) {
            alignCenter(i);
        }
    }
    
    private void filterTable(String text) { 
        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(((DefaultTableModel) tb_riwayat.getModel()));
        if (text.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter(text));
        };
        tb_riwayat.setRowSorter(sorter);
    }
}
