package javafr;

import javax.swing.JPanel;

public class PanelSwaper extends JPanel {
    public  PanelSwaper(JPanel panelParam) {
        this.removeAll();
        this.setLayout(new java.awt.BorderLayout());
        this.setFocusable(false);
        this.add(panelParam);
        this.updateUI();
    }
}
